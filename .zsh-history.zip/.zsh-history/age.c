#include <stdio.h>
#include <omp.h>

int main()
{
    int n = 0;
    scanf("%d", &n);
    int a[n];
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    #pragma omp parallel num_threads(2)
    {
        int tid = omp_get_thread_num();
        for (int i = 0; i < n; i++)
        {
            if (tid == 1 && (a[i] >= 16 && a[i] < 18))
            {
                printf("Person %d: Age %d Eligible. (Thread: %d)\n", i + 1, a[i], tid);
            }
            else if (tid == 0 && (a[i] < 16 || a[i] >= 18))
            {
                printf("Person %d: Age %d Not Eligible. (Thread: %d)\n", i + 1, a[i], tid);
            }
        }
    }
    return 0;
}
