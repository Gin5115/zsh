#include <stdio.h>
#include <omp.h>

int main(){
	
	int n=0;scanf("%d",&n);
	int a[n], b[n], c[n];
	for(int i=0;i<n;i++)scanf("%d",&a[i]);
	for(int i=0;i<n;i++)scanf("%d",&b[i]);

	#pragma omp parallel
	{
		int tid = omp_get_thread_num();
		
		if(tid==0){
			int total_threads = omp_get_num_threads();
			printf("This is the master thread (ID %d).\n", tid);
			printf("Total number of threads: %d\n\n", total_threads);
		}
		#pragma omp for
		for (int i=0;i<n;i++){
			c[i] = a[i] + b[i];
			printf("Thread %d calculated the sum for index %d.\n", tid, i);
		}
	}

	printf("\n Result Array C[] \n");

	for(int i=0;i<n;i++)printf("C[%d] = %d\n",i,c[i]);

	return 0;	
}
