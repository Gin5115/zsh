#include <stdio.h>
#include <omp.h>

void main(){
	int n=0;scanf("%d",&n);
	int odd=0,even=0,arr[n];
	for(int i=0;i<n;i++)scanf("%d",&arr[i]);
	omp_set_num_threads(n);
	
	#pragma omp parallel
	{
		int tid=omp_get_thread_num();
		int ttid=omp_get_num_threads();
		#pragma omp for reduction(+:even,odd)
		for(int i=0;i<n;i++){
			if(arr[i]%2==0){
				even += arr[i];
				printf("Thread %d processing EVEN element %d\n", tid, arr[i]);
			}else{
				odd += arr[i];
				printf("Thread %d processing ODD element %d\n", tid, arr[i]);
			}
		}
		if(tid == 0){
			printf("This is the MASTER thread (Thread 0).\n");
			printf("Total number of threads: %d\n\n",ttid);
		}
	}

	printf("\nTotal EVEN sum = %d\n", even);
    printf("Total ODD sum  = %d\n", odd);
}
