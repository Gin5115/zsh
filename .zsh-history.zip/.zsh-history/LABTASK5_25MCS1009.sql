-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema UniversityDB
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema UniversityDB
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `UniversityDB` DEFAULT CHARACTER SET utf8 ;
USE `UniversityDB` ;

-- -----------------------------------------------------
-- Table `UniversityDB`.`Person`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `UniversityDB`.`Person` (
  `person_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `dob` DATE NULL,
  `phone_number` VARCHAR(15) NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE,
  UNIQUE INDEX `phone_number_UNIQUE` (`phone_number` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `UniversityDB`.`Department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `UniversityDB`.`Department` (
  `dept_id` INT NOT NULL AUTO_INCREMENT,
  `dept_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`dept_id`),
  UNIQUE INDEX `dept_name_UNIQUE` (`dept_name` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `UniversityDB`.`Faculty`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `UniversityDB`.`Faculty` (
  `hire_Date` DATE NOT NULL,
  `specialization` VARCHAR(100) NULL,
  `salary` DECIMAL(10,2) NOT NULL,
  `person_id` INT NOT NULL,
  `dept_id` INT NOT NULL,
  PRIMARY KEY (`person_id`),
  INDEX `fk_Faculty_Person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_Faculty_Department1_idx` (`dept_id` ASC) VISIBLE,
  CONSTRAINT `fk_Faculty_Person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `UniversityDB`.`Person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Faculty_Department1`
    FOREIGN KEY (`dept_id`)
    REFERENCES `UniversityDB`.`Department` (`dept_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `UniversityDB`.`Student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `UniversityDB`.`Student` (
  `major` VARCHAR(100) NULL,
  `enrollment_date` DATE NOT NULL,
  `gpa` DECIMAL(3,2) NULL DEFAULT 0.0,
  `person_id` INT NOT NULL,
  PRIMARY KEY (`person_id`),
  INDEX `fk_Student_Person_idx` (`person_id` ASC) VISIBLE,
  CONSTRAINT `fk_Student_Person`
    FOREIGN KEY (`person_id`)
    REFERENCES `UniversityDB`.`Person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
KEY_BLOCK_SIZE = 1;


-- -----------------------------------------------------
-- Table `UniversityDB`.`Course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `UniversityDB`.`Course` (
  `course_id` VARCHAR(10) NOT NULL,
  `course_name` VARCHAR(45) NOT NULL,
  `credits` INT NOT NULL,
  `dept_id` INT NULL,
  `prerequisite_course_id` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_Course_Course1_idx` (`prerequisite_course_id` ASC) VISIBLE,
  CONSTRAINT `fk_Course_Course1`
    FOREIGN KEY (`prerequisite_course_id`)
    REFERENCES `UniversityDB`.`Course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `UniversityDB`.`Enrollment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `UniversityDB`.`Enrollment` (
  `enrollment_id` INT NOT NULL AUTO_INCREMENT,
  `semester` VARCHAR(45) NOT NULL,
  `grade` VARCHAR(2) NULL,
  `course_id` VARCHAR(10) NOT NULL,
  `faculty_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  UNIQUE INDEX `uq_student_course_semester` (`semester` ASC, `course_id` ASC, `student_id` ASC) VISIBLE,
  INDEX `fk_Enrollment_Course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_Enrollment_Faculty1_idx` (`faculty_id` ASC) VISIBLE,
  INDEX `fk_Enrollment_Student1_idx` (`student_id` ASC) VISIBLE,
  CONSTRAINT `fk_Enrollment_Course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `UniversityDB`.`Course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Enrollment_Faculty1`
    FOREIGN KEY (`faculty_id`)
    REFERENCES `UniversityDB`.`Faculty` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Enrollment_Student1`
    FOREIGN KEY (`student_id`)
    REFERENCES `UniversityDB`.`Student` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- begin attached script 'script'
ALTER TABLE Faculty
ADD CONSTRAINT chk_salary CHECK (SALARY>=0 AND SALARY<=100000);

ALTER TABLE Student
ADD CONSTRAINT chk_gpa CHECK(GPA >= 0.0 AND GPA<=4);

ALTER TABLE Course
ADD CONSTRAINT chk_credits CHECK(CREDITS > 0 AND CREDITS < 6);



-- end attached script 'script'
