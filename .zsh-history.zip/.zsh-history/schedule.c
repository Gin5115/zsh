#include <stdio.h>
#include <omp.h>

int main() {
    int counter;

    printf("=== Quality Checking Unit (Incrementing Counter) ===\n");

    #pragma omp parallel for schedule(static) lastprivate(counter)
    for (counter = 0; counter < 256; counter++);
    printf("Static scheduling max: %d\n", counter);

    #pragma omp parallel for schedule(dynamic) lastprivate(counter)
    for (counter = 0; counter < 256; counter++);
    printf("Dynamic scheduling max: %d\n", counter);

    #pragma omp parallel for schedule(guided) lastprivate(counter)
    for (counter = 0; counter < 256; counter++);
    printf("Guided scheduling max: %d\n", counter);

    printf("\n=== Dispatching Unit (Decrementing Counter) ===\n");

    #pragma omp parallel for schedule(static) lastprivate(counter)
    for (counter = 256; counter > 0; counter--);
    printf("Static scheduling min: %d\n", counter);

    #pragma omp parallel for schedule(dynamic,8) lastprivate(counter)
    for (counter = 256; counter > 0; counter--);
    printf("Dynamic scheduling min: %d\n", counter);

    #pragma omp parallel for schedule(guided,8) lastprivate(counter)
    for (counter = 256; counter > 0; counter--);
    printf("Guided scheduling min: %d\n", counter);

    return 0;
}
