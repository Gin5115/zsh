-- =================================
-- COMPREHENSIVE SAMPLE DATA POPULATION (EXPANDED)
-- =================================

-- Use the correct database
USE esports_platform;

-- To avoid errors from re-running the script, you can uncomment the lines below
-- to clear the tables. This assumes you are not dropping and recreating the tables
-- every time.
/*
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE Users;
TRUNCATE TABLE Players;
TRUNCATE TABLE Games;
TRUNCATE TABLE Teams;
TRUNCATE TABLE Team_Memberships;
TRUNCATE TABLE Tournaments;
TRUNCATE TABLE Tournament_Registrations;
TRUNCATE TABLE Matches;
TRUNCATE TABLE Tournament_Standings;
TRUNCATE TABLE Transaction_Logs;
TRUNCATE TABLE Audit_Trail;
SET FOREIGN_KEY_CHECKS = 1;
*/

-- == 1. USERS & PLAYERS ==
-- Creates the user accounts first, then links player profiles to them.
-- Note: Admin (1) and Organizer (2) are not players.
INSERT INTO Users (user_id, email, password_hash, full_name) VALUES
(1, 'admin@esports.com', SHA2('admin123', 256), 'System Admin'),
(2, 'organizer@esports.com', SHA2('org123', 256), 'Tournament Organizer'),
(3, 'ace@email.com', SHA2('player123', 256), 'Alex Chen'),
(4, 'blaze@email.com', SHA2('player123', 256), 'Ben Carter'),
(5, 'comet@email.com', SHA2('player123', 256), 'Chloe Davis'),
(6, 'dash@email.com', SHA2('player123', 256), 'David Evans'),
(7, 'echo@email.com', SHA2('player123', 256), 'Emily Frank'),
(8, 'fury@email.com', SHA2('player123', 256), 'Frank Green'),
(9, 'ghost@email.com', SHA2('player123', 256), 'Grace Hill'),
(10, 'hawk@email.com', SHA2('player123', 256), 'Henry Irwin'),
(11, 'iris@email.com', SHA2('player123', 256), 'Ivy Jones'),
(12, 'jade@email.com', SHA2('player123', 256), 'Jack King'),
(13, 'kilo@email.com', SHA2('player123', 256), 'Kevin Lee'),
(14, 'luna@email.com', SHA2('player123', 256), 'Laura Miller'),
(15, 'maverick@email.com', SHA2('player123', 256), 'Mason Noah'),
(16, 'nova@email.com', SHA2('player123', 256), 'Nora Oliver'),
(17, 'orion@email.com', SHA2('player123', 256), 'Owen Patel'),
(18, 'phoenix@email.com', SHA2('player123', 256), 'Penelope Quinn'),
(19, 'raven@email.com', SHA2('player123', 256), 'Riley Roberts'),
(20, 'spectre@email.com', SHA2('player123', 256), 'Sam Taylor'),
(21, 'titan@email.com', SHA2('player123', 256), 'Tom Ultimate'),
(22, 'vortex@email.com', SHA2('player123', 256), 'Violet White');

INSERT INTO Players (player_id, gamer_tag, skill_rating, country) VALUES
(3, 'Ace', 1800, 'USA'),
(4, 'Blaze', 1750, 'Canada'),
(5, 'Comet', 1900, 'UK'),
(6, 'Dash', 1650, 'Australia'),
(7, 'Echo', 2100, 'Germany'),
(8, 'Fury', 2050, 'Sweden'),
(9, 'Ghost', 1950, 'South Korea'),
(10, 'Hawk', 1850, 'Brazil'),
(11, 'Iris', 2200, 'Japan'),
(12, 'Jade', 2150, 'France'),
(13, 'Kilo', 1700, 'Mexico'),
(14, 'Luna', 1600, 'Spain'),
(15, 'Maverick', 1980, 'USA'),
(16, 'Nova', 2020, 'Canada'),
(17, 'Orion', 2150, 'UK'),
(18, 'Phoenix', 1900, 'Australia'),
(19, 'Raven', 2250, 'Germany'),
(20, 'Spectre', 2300, 'Sweden'),
(21, 'Titan', 2400, 'South Korea'),
(22, 'Vortex', 2350, 'Brazil');

-- == 2. GAMES ==
INSERT INTO Games (game_id, game_name, genre, publisher, max_team_size) VALUES
(1, 'Counter-Strike 2', 'FPS', 'Valve', 5),
(2, 'Dota 2', 'MOBA', 'Valve', 5),
(3, 'Valorant', 'FPS', 'Riot Games', 5),
(4, 'League of Legends', 'MOBA', 'Riot Games', 5);

-- == 3. TEAMS & MEMBERSHIPS ==
-- Creates 8 teams and populates them with players.
INSERT INTO Teams (team_id, team_name, captain_id) VALUES
(1, 'Atomic Nova', 3), (2, 'Blue Phoenix', 7), (3, 'Crimson Guard', 11), (4, 'Shadow Strikers', 9),
(5, 'Gale Force', 15), (6, 'Ironclad Legion', 19), (7, 'Celestial Knights', 21), (8, 'Viper Squad', 17);

INSERT INTO Team_Memberships (team_id, player_id, join_date, role) VALUES
-- Team 1: Atomic Nova
(1, 3, '2024-01-10', 'captain'),(1, 4, '2024-01-11', 'member'),(1, 5, '2024-01-12', 'member'),(1, 6, '2024-02-01', 'member'),(1, 13, '2024-03-05', 'member'),
-- Team 2: Blue Phoenix
(2, 7, '2024-01-15', 'captain'),(2, 8, '2024-01-15', 'member'),(2, 10, '2024-02-20', 'member'),(2, 14, '2024-03-10', 'member'),(2, 18, '2024-04-01', 'member'),
-- Team 3: Crimson Guard
(3, 11, '2024-01-20', 'captain'),(3, 12, '2024-01-21', 'member'),
-- Team 4: Shadow Strikers
(4, 9, '2024-02-01', 'captain'),
-- Team 5: Gale Force
(5, 15, '2024-02-10', 'captain'),(5, 16, '2024-02-11', 'member'),
-- Team 6: Ironclad Legion
(6, 19, '2024-03-01', 'captain'),(6, 20, '2024-03-02', 'member'),
-- Team 7: Celestial Knights
(7, 21, '2024-03-15', 'captain'),
-- Team 8: Viper Squad
(8, 17, '2024-04-01', 'captain');

-- == 4. TOURNAMENTS ==
INSERT INTO Tournaments (tournament_id, name, game_id, start_date, end_date, prize_pool, organizer_id, status, max_teams) VALUES
(1, 'Summer Valorant Major', 3, '2025-07-15', '2025-07-25', 25000.00, 2, 'upcoming', 16),
(2, 'CS2 Champions League', 1, '2025-09-01', '2025-09-15', 50000.00, 2, 'ongoing', 8),
(3, 'Spring Dota 2 Invitational', 2, '2025-04-10', '2025-04-20', 15000.00, 2, 'completed', 4),
(4, 'Winter LoL Open', 4, '2025-12-01', '2025-12-10', 10000.00, 2, 'cancelled', 32);

-- == 5. TOURNAMENT REGISTRATIONS ==
-- Registrations for the UPCOMING Summer Valorant Major
CALL RegisterTeamForTournament(1, 2, 250.00); -- Blue Phoenix
CALL RegisterTeamForTournament(1, 5, 250.00); -- Gale Force

-- Registrations for the ONGOING CS2 Champions League (filling it up)
CALL RegisterTeamForTournament(2, 1, 500.00); -- Atomic Nova
CALL RegisterTeamForTournament(2, 4, 500.00); -- Shadow Strikers
CALL RegisterTeamForTournament(2, 6, 500.00); -- Ironclad Legion
CALL RegisterTeamForTournament(2, 8, 500.00); -- Viper Squad

-- Registrations for the COMPLETED Spring Dota 2 Invitational (4 teams)
-- Manually inserting as the procedure blocks completed tournaments
INSERT INTO Tournament_Registrations(tournament_id, team_id, payment_status) VALUES (3, 3, 'completed'),(3, 7, 'completed');
INSERT INTO Tournament_Standings(tournament_id, team_id) VALUES (3, 3),(3, 7);
UPDATE Tournaments SET current_teams = 2 WHERE tournament_id = 3;

-- == 6. MATCHES ==
-- Populates a fuller history of matches.

-- Matches for ONGOING CS2 Champions League (Tournament 2) - Round 1
INSERT INTO Matches(tournament_id, round_number, team1_id, team2_id, scheduled_time, status) VALUES 
(2, 1, 1, 8, '2025-09-02 18:00:00', 'scheduled'),
(2, 1, 4, 6, '2025-09-02 20:00:00', 'scheduled');
-- One match is already completed
INSERT INTO Matches(match_id, tournament_id, round_number, team1_id, team2_id, scheduled_time) VALUES
(100, 2, 1, 1, 4, '2025-09-01 18:00:00');
UPDATE Matches SET status = 'completed', team1_score = 16, team2_score = 12, winner_team_id = 1 WHERE match_id = 100;

-- Full match history for COMPLETED Spring Dota 2 Invitational (Tournament 3)
-- This will fire the update_tournament_standings trigger multiple times, creating a full leaderboard.
INSERT INTO Matches(match_id, tournament_id, round_number, team1_id, team2_id, scheduled_time) VALUES
(101, 3, 1, 3, 7, '2025-04-12 14:00:00'); -- Semi-Final 1

-- Updates for completed matches. THESE WILL TRIGGER THE STANDINGS UPDATE.
UPDATE Matches SET status = 'completed', team1_score = 2, team2_score = 1, winner_team_id = 3 WHERE match_id = 101;

-- To verify the trigger worked, you can run:
-- SELECT t.team_name, ts.* FROM Tournament_Standings ts JOIN Teams t ON ts.team_id = t.team_id WHERE ts.tournament_id = 3 ORDER BY ts.points DESC;

-- You can also test prize distribution for the winner of the completed tournament:
-- CALL DistributePrizeMoney(3, 3, 10000.00);
-- SELECT * FROM Transaction_Logs WHERE tournament_id = 3;

