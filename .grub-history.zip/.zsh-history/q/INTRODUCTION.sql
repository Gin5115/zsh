create database researchportaldb;
use researchportaldb;

create table professor(
	prof_id int primary key auto_increment,
    prof_name varchar(255) not null,
    department varchar(100),
    designation varchar(100),
    email varchar(255) unique not null,
    phone varchar(15),
    hire_date date
);

create table students (
	student_id int primary key auto_increment,
    student_name varchar(255) not null,
    department varchar(50),
    city varchar(100),
    email varchar(255) unique not null,
    phone varchar(15),
    enrollment_date date
);

create table projects(
	project_id int primary key auto_increment,
    project_title varchar(255) not null,
    start_date date,
    end_date date,
    status enum('Active', 'Completed', 'On Hold') DEFAULT 'Active',
    supervisor_prof_id int,
    totalfunding decimal(15,2),
    foreign key (supervisor_prof_id) references professor(prof_id),
    CHECK (totalfunding <= 1000000)
);

create table funding_agencies(
	agency_id int primary key auto_increment,
    agency_name varchar(255) not null,
    country varchar(100),
    state varchar(100),
    email varchar(255) unique not null,
    phone varchar(15)
);

create table publications(
	pub_id int primary key auto_increment,
    pub_title text not null,
    journal_name varchar(255),
    pub_year year,
    project_id int,
    foreign key (project_id) references projects(project_id)
);

-- Junction table for Project and Student participation (M:N)
create table student_project(
	student_id int,
    project_id int,
    status enum('Active','Completed'),
    primary key (student_id, project_id),
    foreign key (student_id) references students(student_id),
	foreign key (project_id) references projects(project_id)
);

-- Junction table for Project funding (M:N)
create table project_funding(
	project_id int,
    agency_id int,
    funding decimal(15,2),
    year year,
    primary key(project_id, agency_id),
    foreign key (agency_id) references funding_Agencies(agency_id),
	foreign key (project_id) references projects(project_id)
);

-- Junction table for Publication authors (M:N with Professors and Students)
create table publication_authors(
	author_id int primary key auto_increment,
	pub_id int not null,
    prof_id int null,
    student_id int null,
    foreign key (student_id) references students(student_id),
    foreign key (prof_id) references professor(prof_id),
	foreign key (pub_id) references publications(pub_id),
    unique(pub_id,prof_id,student_id)
);

insert into professor (prof_name, department, designation, email, phone, hire_date) values
('Dr. Evelyn Reed', 'Computer Science', 'Professor', 'e.reed@university.edu', '9876543210', '2010-08-15'),
('Dr. Samuel Chen', 'Physics', 'Associate Professor', 's.chen@university.edu', '9876543211', '2012-06-20'),
('Dr. Priya Sharma', 'Biology', 'Assistant Professor', 'p.sharma@university.edu', '9876543212', '2018-01-10'),
('Dr. Ben Carter', 'Computer Science', 'Professor', 'b.carter@university.edu', '9876543213', '2008-11-05'),
('Dr. Aisha Khan', 'Chemistry', 'Associate Professor', 'a.khan@university.edu', '9876543214', '2014-03-22'),
('Dr. Marcus Holloway', 'Mechanical Engg', 'Professor', 'm.holloway@university.edu', '9876543215', '2005-09-01'),
('Dr. Olivia Kim', 'Civil Engg', 'Assistant Professor', 'o.kim@university.edu', '9876543216', '2020-07-30'),
('Dr. Leo Martinez', 'Mathematics', 'Professor', 'l.martinez@university.edu', '9876543217', '2009-04-12'),
('Dr. Sofia Garcia', 'Electrical Engg', 'Associate Professor', 's.garcia@university.edu', '9876543218', '2015-10-18'),
('Dr. David Lee', 'Computer Science', 'Assistant Professor', 'd.lee@university.edu', '9876543219', '2021-02-25'),
('Dr. Chloe Wilson', 'Biotechnology', 'Professor', 'c.wilson@university.edu', '9876543220', '2011-05-14'),
('Dr. Mason Rodriguez', 'Physics', 'Associate Professor', 'm.rodriguez@university.edu', '9876543221', '2016-08-09'),
('Dr. Isabella Nguyen', 'Chemistry', 'Assistant Professor', 'i.nguyen@university.edu', '9876543222', '2019-11-03'),
('Dr. Ethan Wright', 'Mechanical Engg', 'Professor', 'e.wright@university.edu', '9876543223', '2007-01-20'),
('Dr. Mia Scott', 'Civil Engg', 'Associate Professor', 'm.scott@university.edu', '9876543224', '2013-06-15'),
('Dr. Noah King', 'Mathematics', 'Assistant Professor', 'n.king@university.edu', '9876543225', '2022-09-01'),
('Dr. Ava Green', 'Electrical Engg', 'Professor', 'a.green@university.edu', '9876543226', '2006-12-10'),
('Dr. James Adams', 'Computer Science', 'Associate Professor', 'j.adams@university.edu', '9876543227', '2017-02-28'),
('Dr. Harper Baker', 'Biotechnology', 'Assistant Professor', 'h.baker@university.edu', '9876543228', '2023-04-19'),
('Dr. Logan Clark', 'Physics', 'Professor', 'l.clark@university.edu', '9876543229', '2004-07-22');

insert into students (student_name, department, city, email, phone, enrollment_date) values
('Alice Johnson', 'Computer Science', 'New York', 'alice.j@university.edu', '8765432109', '2022-08-20'),
('Bob Williams', 'Physics', 'Mumbai', 'bob.w@university.edu', '8765432108', '2021-08-18'),
('Charlie Brown', 'Biology', 'London', 'charlie.b@university.edu', '8765432107', '2023-09-01'),
('Diana Miller', 'Computer Science', 'Chennai', 'diana.m@university.edu', '8765432106', '2022-08-21'),
('Eve Davis', 'Chemistry', 'Tokyo', 'eve.d@university.edu', '8765432105', '2021-09-05'),
('Frank Garcia', 'Mechanical Engg', 'Sydney', 'frank.g@university.edu', '8765432104', '2020-08-15'),
('Grace Rodriguez', 'Civil Engg', 'Delhi', 'grace.r@university.edu', '8765432103', '2023-08-25'),
('Henry Wilson', 'Mathematics', 'Paris', 'henry.w@university.edu', '8765432102', '2022-09-02'),
('Ivy Moore', 'Electrical Engg', 'Berlin', 'ivy.m@university.edu', '8765432101', '2021-08-28'),
('Jack Taylor', 'Computer Science', 'Bangalore', 'jack.t@university.edu', '8765432100', '2023-08-19'),
('Kate Anderson', 'Biotechnology', 'Seoul', 'kate.a@university.edu', '8765432119', '2020-09-10'),
('Liam Thomas', 'Physics', 'Moscow', 'liam.t@university.edu', '8765432118', '2022-08-22'),
('Mia Jackson', 'Chemistry', 'Beijing', 'mia.j@university.edu', '8765432117', '2021-08-30'),
('Noah White', 'Mechanical Engg', 'Toronto', 'noah.w@university.edu', '8765432116', '2023-09-03'),
('Olivia Harris', 'Civil Engg', 'Dubai', 'olivia.h@university.edu', '8765432115', '2020-08-25'),
('Peter Martin', 'Mathematics', 'Singapore', 'peter.m@university.edu', '8765432114', '2022-08-29'),
('Quinn Thompson', 'Electrical Engg', 'Hong Kong', 'quinn.t@university.edu', '8765432113', '2021-09-01'),
('Ryan Clark', 'Computer Science', 'San Francisco', 'ryan.c@university.edu', '8765432112', '2023-08-23'),
('Sophia Lewis', 'Biotechnology', 'Boston', 'sophia.l@university.edu', '8765432111', '2020-08-28'),
('Tom Robinson', 'Physics', 'Chicago', 'tom.r@university.edu', '8765432110', '2022-09-04');

insert into projects (project_title, start_date, end_date, status, supervisor_prof_id, totalfunding) values
('AI in Medical Imaging', '2024-01-15', '2025-12-31', 'Active', 1, 950000.00),
('Quantum Entanglement Studies', '2023-09-01', '2025-08-30', 'Active', 2, 850000.00),
('Gene Sequencing of Extremophiles', '2024-03-10', '2026-03-09', 'Active', 3, 750000.00),
('Advanced Cryptography Algorithms', '2022-06-01', '2024-05-31', 'Completed', 4, 600000.00),
('Catalytic Converter Efficiency', '2023-11-20', '2025-11-19', 'Active', 5, 900000.00),
('Robotic Arm Motion Planning', '2024-02-01', '2026-01-31', 'Active', 6, 980000.00),
('Sustainable Building Materials', '2023-07-15', '2025-07-14', 'Active', 7, 800000.00),
('Number Theory in Modern Cryptography', '2024-04-01', '2026-03-31', 'On Hold', 8, 450000.00),
('5G Network Slicing Technology', '2022-10-10', '2024-10-09', 'Completed', 9, 700000.00),
('Machine Learning for Stock Prediction', '2023-08-01', '2025-07-31', 'Active', 10, 880000.00),
('CRISPR-Cas9 Gene Editing', '2024-05-20', '2026-05-19', 'Active', 11, 920000.00),
('Dark Matter Particle Detection', '2023-01-10', '2025-01-09', 'Active', 12, 990000.00),
('Organic Polymer Synthesis', '2022-09-05', '2024-09-04', 'Completed', 13, 550000.00),
('Fluid Dynamics in Jet Engines', '2024-06-01', '2026-05-31', 'Active', 14, 960000.00),
('Earthquake Resistant Structures', '2023-04-12', '2025-04-11', 'Active', 15, 820000.00),
('Graph Theory and Network Analysis', '2022-11-01', '2024-10-31', 'Completed', 16, 480000.00),
('Wireless Power Transfer Systems', '2024-07-01', '2026-06-30', 'Active', 17, 890000.00),
('Natural Language Processing for Chatbots', '2023-05-15', '2025-05-14', 'Active', 18, 930000.00),
('Bio-remediation of Industrial Waste', '2022-08-20', '2024-08-19', 'Completed', 19, 650000.00),
('Stellar Evolution Modeling', '2024-08-01', '2026-07-31', 'Active', 20, 970000.00);

insert into funding_agencies (agency_name, country, state, email, phone) values
('National Science Foundation', 'USA', 'Virginia', 'contact@nsf.gov', '1234567890'),
('Dept. of Science & Technology', 'India', 'Delhi', 'info@dst.gov.in', '1234567891'),
('European Research Council', 'Belgium', 'Brussels', 'contact@erc.europa.eu', '1234567892'),
('UK Research and Innovation', 'UK', 'Wiltshire', 'support@ukri.org', '1234567893'),
('German Research Foundation', 'Germany', 'Bonn', 'info@dfg.de', '1234567894'),
('Japan Science and Technology Agency', 'Japan', 'Saitama', 'contact@jst.go.jp', '1234567895'),
('National Research Foundation of Korea', 'South Korea', 'Daejeon', 'webmaster@nrf.re.kr', '1234567896'),
('Australian Research Council', 'Australia', 'Canberra', 'info@arc.gov.au', '1234567897'),
('Natural Sciences and Engineering Research Council', 'Canada', 'Ontario', 'contact@nserc-crsng.gc.ca', '1234567898'),
('Swiss National Science Foundation', 'Switzerland', 'Bern', 'info@snf.ch', '1234567899'),
('The Wellcome Trust', 'UK', 'London', 'contact@wellcome.ac.uk', '1234567880'),
('Bill & Melinda Gates Foundation', 'USA', 'Washington', 'info@gatesfoundation.org', '1234567881'),
('Indian Council of Medical Research', 'India', 'Delhi', 'contact@icmr.gov.in', '1234567882'),
('Max Planck Society', 'Germany', 'Munich', 'info@mpg.de', '1234567883'),
('CNRS (French National Centre for Scientific Research)', 'France', 'Paris', 'contact@cnrs.fr', '1234567884'),
('CSIRO (Commonwealth Scientific and Industrial Research Organisation)', 'Australia', 'Canberra', 'enquiries@csiro.au', '1234567885'),
('Tata Trusts', 'India', 'Mumbai', 'contact@tatatrusts.org', '1234567886'),
('Howard Hughes Medical Institute', 'USA', 'Maryland', 'info@hhmi.org', '1234567887'),
('Azim Premji Foundation', 'India', 'Bangalore', 'contact@azimpremjifoundation.org', '1234567888'),
('Volkswagen Foundation', 'Germany', 'Hanover', 'info@volkswagenstiftung.de', '1234567889');

insert into publications (pub_title, journal_name, pub_year, project_id) values
('A Novel Approach to Neural Network Optimization', 'Journal of Machine Learning Research', 2025, 1),
('Experimental Verification of Bell\'s Theorem', 'Physical Review Letters', 2024, 2),
('Genomic Insights into Halophilic Archaea', 'Nature Microbiology', 2025, 3),
('Post-Quantum Cryptography: A Survey', 'IEEE Security & Privacy', 2023, 4),
('Improving NOx Reduction in Gasoline Engines', 'SAE International Journal of Engines', 2024, 5),
('Collision-Free Path Planning for 7-DOF Robots', 'IEEE Transactions on Robotics', 2025, 6),
('Bamboo-Reinforced Concrete Beams', 'Construction and Building Materials', 2024, 7),
('Lattice-Based Cryptography Implementation', 'Journal of Cryptology', 2025, 8),
('Dynamic Resource Allocation in 5G Networks', 'IEEE Transactions on Wireless Communications', 2023, 9),
('LSTM Networks for Financial Time Series Forecasting', 'Journal of Financial Data Science', 2024, 10),
('Targeted Gene Disruption using CRISPR', 'Cell', 2025, 11),
('Searching for WIMPs with Liquid Xenon Detectors', 'Astroparticle Physics', 2024, 12),
('Synthesis of Biodegradable Polymers', 'Journal of Polymer Science', 2023, 13),
('Aerodynamic Simulation of Turbine Blades', 'AIAA Journal', 2025, 14),
('Seismic Performance of Base-Isolated Buildings', 'Earthquake Engineering & Structural Dynamics', 2024, 15),
('Community Detection in Social Networks', 'Journal of Complex Networks', 2023, 16),
('Resonant-Coupled Wireless Power Transfer', 'IEEE Transactions on Power Electronics', 2025, 17),
('Sentiment Analysis using Transformer Models', 'Proceedings of the ACL', 2024, 18),
('Microbial Degradation of Phenolic Compounds', 'Applied and Environmental Microbiology', 2023, 19),
('Modeling the Life Cycle of Low-Mass Stars', 'The Astrophysical Journal', 2025, 20);

insert into project_funding (project_id, agency_id, funding, year) values
(1, 1, 600000.00, 2024), (1, 2, 350000.00, 2024),
(2, 3, 850000.00, 2023),
(3, 2, 750000.00, 2024),
(4, 1, 600000.00, 2022),
(5, 4, 500000.00, 2023), (5, 5, 400000.00, 2023),
(6, 6, 980000.00, 2024),
(7, 7, 800000.00, 2023),
(8, 8, 450000.00, 2024),
(9, 9, 700000.00, 2022),
(10, 10, 880000.00, 2023),
(11, 11, 920000.00, 2024),
(12, 12, 990000.00, 2023),
(13, 13, 550000.00, 2022),
(14, 14, 960000.00, 2024),
(15, 15, 820000.00, 2023),
(16, 16, 480000.00, 2022),
(17, 17, 890000.00, 2024),
(18, 18, 430000.00, 2023), (18, 1, 500000.00, 2023);

insert into student_project (student_id, project_id, status) values
(1, 1, 'Active'), (1, 6, 'Active'),
(2, 2, 'Active'),
(3, 3, 'Active'),
(4, 1, 'Active'), (4, 4, 'Completed'),
(5, 5, 'Active'),
(6, 6, 'Active'),
(7, 7, 'Active'),
(8, 8, 'Active'),
(9, 9, 'Completed'),
(10, 10, 'Active'),
(11, 11, 'Active'),
(12, 12, 'Active'),
(13, 13, 'Completed'),
(14, 14, 'Active'),
(15, 15, 'Active'),
(18, 17, 'Active'), (18, 18, 'Active'),
(1, 19, 'Completed'),
(2, 12, 'Active');

insert into publication_authors (pub_id, prof_id, student_id) values
(1, 1, NULL), (1, NULL, 1), (1, NULL, 4),
(2, 2, NULL), (2, NULL, 2),
(3, 3, NULL), (3, NULL, 3),
(4, 4, NULL), (4, NULL, 4),
(5, 5, NULL), (5, NULL, 5),
(6, 6, NULL), (6, NULL, 1), (6, NULL, 6),
(7, 7, NULL), (7, NULL, 7),
(8, 8, NULL), (8, NULL, 8),
(9, 9, NULL), (9, NULL, 9),
(10, 10, NULL), (10, NULL, 10),
(11, 11, NULL), (11, NULL, 11),
(12, 12, NULL), (12, NULL, 2), (12, NULL, 12),
(13, 13, NULL), (13, NULL, 13),
(14, 14, NULL), (14, NULL, 14),
(15, 15, NULL), (15, NULL, 15),
(16, 16, NULL),
(17, 17, NULL), (17, NULL, 18),
(18, 18, NULL), (18, NULL, 18),
(19, 19, NULL), (19, NULL, 1),
(20, 20, NULL);

select funding from project_funding where project_id=1 and agency_id=1;
update project_funding
set funding = 620000.00
where project_id = 1 AND agency_id = 1;

select totalfunding from projects where project_id=1;
update projects
set totalfunding = (SELECT SUM(funding) from project_funding where project_id=1)
where project_id=1;

delete from publication_authors
where pub_id=20;

delete from publications
where pub_id=20;

select *
from students
where department = 'Computer Science' OR city = 'Mumbai';

select *
from projects
where totalfunding > 500000;

select *
from professor
where designation='Associate Professor';

select *
from funding_agencies
where country='India';

select *
from publications
where pub_year = 2024;