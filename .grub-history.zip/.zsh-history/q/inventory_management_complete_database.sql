-- ============================================================================
-- COMPREHENSIVE INVENTORY MANAGEMENT SYSTEM DATABASE
-- Advanced Database Features Implementation
-- Team Project with Triggers, Transactions, Authentication, and EXPLAIN
-- ============================================================================


-- ============================================================================
-- COMPREHENSIVE INVENTORY MANAGEMENT SYSTEM DATABASE
-- Team Project: Advanced Database Features Implementation
-- ============================================================================

-- Create the main database
CREATE DATABASE InventoryManagementSystem;
USE InventoryManagementSystem;

-- ============================================================================
-- PART 1: CORE TABLES (Database Design)
-- ============================================================================

-- Users table for authentication
CREATE TABLE users (
    user_id INT PRIMARY KEY IDENTITY(1,1),
    username NVARCHAR(50) UNIQUE NOT NULL,
    password_hash NVARCHAR(256) NOT NULL, -- Store hashed passwords
    email NVARCHAR(100) UNIQUE NOT NULL,
    role NVARCHAR(20) NOT NULL CHECK (role IN ('admin', 'manager', 'employee')),
    is_active BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE(),
    last_login DATETIME,
    failed_login_attempts INT DEFAULT 0,
    account_locked_until DATETIME NULL
);

-- Categories table
CREATE TABLE categories (
    category_id INT PRIMARY KEY IDENTITY(1,1),
    category_name NVARCHAR(50) NOT NULL,
    description NVARCHAR(200),
    created_at DATETIME DEFAULT GETDATE(),
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- Suppliers table
CREATE TABLE suppliers (
    supplier_id INT PRIMARY KEY IDENTITY(1,1),
    supplier_name NVARCHAR(100) NOT NULL,
    contact_person NVARCHAR(100),
    email NVARCHAR(100),
    phone NVARCHAR(20),
    address NVARCHAR(200),
    city NVARCHAR(50),
    state NVARCHAR(50),
    postal_code NVARCHAR(10),
    country NVARCHAR(50),
    payment_terms NVARCHAR(100),
    is_active BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE()
);

-- Products table
CREATE TABLE products (
    product_id INT PRIMARY KEY IDENTITY(1,1),
    product_name NVARCHAR(100) NOT NULL,
    sku NVARCHAR(50) UNIQUE NOT NULL,
    description NVARCHAR(500),
    category_id INT,
    unit_price DECIMAL(10,2) NOT NULL,
    cost_price DECIMAL(10,2) NOT NULL,
    reorder_level INT DEFAULT 10,
    max_stock_level INT DEFAULT 1000,
    unit_of_measure NVARCHAR(20) DEFAULT 'pcs',
    barcode NVARCHAR(50),
    is_active BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

-- Inventory table (main stock tracking)
CREATE TABLE inventory (
    inventory_id INT PRIMARY KEY IDENTITY(1,1),
    product_id INT NOT NULL,
    quantity_in_stock INT NOT NULL DEFAULT 0,
    reserved_quantity INT DEFAULT 0, -- For pending orders
    location NVARCHAR(50) DEFAULT 'Main Warehouse',
    last_updated DATETIME DEFAULT GETDATE(),
    updated_by INT,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (updated_by) REFERENCES users(user_id)
);

-- Purchase Orders table
CREATE TABLE purchase_orders (
    order_id INT PRIMARY KEY IDENTITY(1,1),
    supplier_id INT NOT NULL,
    order_date DATETIME DEFAULT GETDATE(),
    expected_date DATE,
    status NVARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'shipped', 'received', 'cancelled')),
    total_amount DECIMAL(12,2) DEFAULT 0,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    notes NVARCHAR(500),
    created_by INT NOT NULL,
    approved_by INT,
    approved_date DATETIME,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id)
);

-- Purchase Order Details table
CREATE TABLE purchase_order_details (
    detail_id INT PRIMARY KEY IDENTITY(1,1),
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity_ordered INT NOT NULL,
    quantity_received INT DEFAULT 0,
    unit_cost DECIMAL(10,2) NOT NULL,
    line_total DECIMAL(10,2) AS (quantity_ordered * unit_cost),
    FOREIGN KEY (order_id) REFERENCES purchase_orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Sales Orders table
CREATE TABLE sales_orders (
    order_id INT PRIMARY KEY IDENTITY(1,1),
    customer_name NVARCHAR(100) NOT NULL,
    customer_email NVARCHAR(100),
    customer_phone NVARCHAR(20),
    order_date DATETIME DEFAULT GETDATE(),
    required_date DATE,
    status NVARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'shipped', 'delivered', 'cancelled')),
    total_amount DECIMAL(12,2) DEFAULT 0,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    discount_amount DECIMAL(10,2) DEFAULT 0,
    shipping_address NVARCHAR(300),
    payment_status NVARCHAR(20) DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'partial', 'refunded')),
    created_by INT NOT NULL,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- Sales Order Details table
CREATE TABLE sales_order_details (
    detail_id INT PRIMARY KEY IDENTITY(1,1),
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity_ordered INT NOT NULL,
    quantity_shipped INT DEFAULT 0,
    unit_price DECIMAL(10,2) NOT NULL,
    line_total DECIMAL(10,2) AS (quantity_ordered * unit_price),
    FOREIGN KEY (order_id) REFERENCES sales_orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Stock Transactions table (audit trail)
CREATE TABLE stock_transactions (
    transaction_id INT PRIMARY KEY IDENTITY(1,1),
    product_id INT NOT NULL,
    transaction_type NVARCHAR(20) NOT NULL CHECK (transaction_type IN ('purchase', 'sale', 'adjustment', 'transfer', 'return')),
    quantity_change INT NOT NULL, -- positive for stock in, negative for stock out
    quantity_before INT NOT NULL,
    quantity_after INT NOT NULL,
    unit_cost DECIMAL(10,2),
    reference_type NVARCHAR(20), -- 'purchase_order', 'sales_order', 'adjustment'
    reference_id INT, -- ID of the source document
    transaction_date DATETIME DEFAULT GETDATE(),
    notes NVARCHAR(200),
    created_by INT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- User Activity Log table (security audit)
CREATE TABLE user_activity_log (
    log_id INT PRIMARY KEY IDENTITY(1,1),
    user_id INT,
    activity_type NVARCHAR(50) NOT NULL,
    table_affected NVARCHAR(50),
    record_id INT,
    action_performed NVARCHAR(20) NOT NULL CHECK (action_performed IN ('INSERT', 'UPDATE', 'DELETE', 'SELECT')),
    old_values NVARCHAR(MAX),
    new_values NVARCHAR(MAX),
    ip_address NVARCHAR(45),
    user_agent NVARCHAR(200),
    timestamp DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ============================================================================
-- PART 2: INDEXES FOR PERFORMANCE
-- ============================================================================

-- Primary indexes are automatically created, adding secondary indexes
CREATE INDEX IX_products_sku ON products(sku);
CREATE INDEX IX_products_category ON products(category_id);
CREATE INDEX IX_inventory_product ON inventory(product_id);
CREATE INDEX IX_transactions_product_date ON stock_transactions(product_id, transaction_date);
CREATE INDEX IX_purchase_orders_supplier ON purchase_orders(supplier_id);
CREATE INDEX IX_sales_orders_customer ON sales_orders(customer_name);
CREATE INDEX IX_users_username ON users(username);
CREATE INDEX IX_activity_log_user_date ON user_activity_log(user_id, timestamp);




-- ============================================================================
-- SAMPLE DATA INSERTION
-- ============================================================================

-- Insert sample users (passwords are hashed versions of 'password123')
INSERT INTO users (username, password_hash, email, role) VALUES
('admin', HASHBYTES('SHA2_256', 'password123'), 'admin@inventory.com', 'admin'),
('manager1', HASHBYTES('SHA2_256', 'password123'), 'manager1@inventory.com', 'manager'),
('employee1', HASHBYTES('SHA2_256', 'password123'), 'employee1@inventory.com', 'employee'),
('employee2', HASHBYTES('SHA2_256', 'password123'), 'employee2@inventory.com', 'employee'),
('demo_user', HASHBYTES('SHA2_256', 'password123'), 'demo@inventory.com', 'employee');

-- Insert categories
INSERT INTO categories (category_name, description, created_by) VALUES
('Electronics', 'Electronic devices and components', 1),
('Office Supplies', 'General office supplies and stationery', 1),
('Computer Hardware', 'Computer parts and accessories', 1),
('Software', 'Software licenses and applications', 1),
('Furniture', 'Office and warehouse furniture', 1);

-- Insert suppliers
INSERT INTO suppliers (supplier_name, contact_person, email, phone, address, city, state, postal_code, country, payment_terms) VALUES
('TechCorp Solutions', 'John Smith', 'john@techcorp.com', '+1-555-0101', '123 Tech Street', 'San Francisco', 'CA', '94105', 'USA', 'Net 30'),
('Office Plus Inc', 'Sarah Johnson', 'sarah@officeplus.com', '+1-555-0102', '456 Business Ave', 'New York', 'NY', '10001', 'USA', 'Net 30'),
('Global Electronics', 'Mike Chen', 'mike@globalelec.com', '+1-555-0103', '789 Electronic Blvd', 'Austin', 'TX', '73301', 'USA', 'Net 45'),
('Furniture World', 'Lisa Brown', 'lisa@furnitureworld.com', '+1-555-0104', '321 Furniture Way', 'Chicago', 'IL', '60601', 'USA', 'Net 30'),
('Software Solutions Ltd', 'David Wilson', 'david@softwaresol.com', '+1-555-0105', '654 Software Park', 'Seattle', 'WA', '98101', 'USA', 'Net 15');

-- Insert products
INSERT INTO products (product_name, sku, description, category_id, unit_price, cost_price, reorder_level, max_stock_level, unit_of_measure) VALUES
('Laptop Dell Inspiron 15', 'DELL-INS-15', 'Dell Inspiron 15 laptop with 8GB RAM', 3, 899.99, 650.00, 5, 50, 'pcs'),
('Wireless Mouse Logitech', 'LOG-MOUSE-W1', 'Logitech wireless optical mouse', 3, 29.99, 18.50, 20, 200, 'pcs'),
('Office Chair Executive', 'CHAIR-EXEC-01', 'Executive office chair with lumbar support', 5, 299.99, 180.00, 3, 30, 'pcs'),
('Printer Paper A4', 'PAPER-A4-500', '500 sheets A4 printing paper', 2, 12.99, 8.50, 50, 500, 'ream'),
('USB Flash Drive 32GB', 'USB-32GB-01', '32GB USB 3.0 flash drive', 3, 19.99, 12.00, 25, 250, 'pcs'),
('Microsoft Office 365', 'MS-O365-1Y', 'Microsoft Office 365 1-year license', 4, 149.99, 120.00, 10, 100, 'license'),
('Ethernet Cable 5m', 'ETH-CBL-5M', '5 meter ethernet cable Cat6', 3, 15.99, 8.75, 30, 300, 'pcs'),
('Desk Lamp LED', 'LAMP-LED-01', 'LED desk lamp with adjustable brightness', 2, 45.99, 28.00, 15, 100, 'pcs'),
('Keyboard Mechanical', 'KB-MECH-01', 'Mechanical keyboard with RGB lighting', 3, 129.99, 85.00, 8, 80, 'pcs'),
('Monitor 24inch', 'MON-24-01', '24 inch LED monitor Full HD', 3, 199.99, 140.00, 5, 40, 'pcs');

-- Insert initial inventory
INSERT INTO inventory (product_id, quantity_in_stock, location, updated_by) VALUES
(1, 25, 'Main Warehouse', 1),
(2, 150, 'Main Warehouse', 1),
(3, 12, 'Main Warehouse', 1),
(4, 200, 'Main Warehouse', 1),
(5, 75, 'Main Warehouse', 1),
(6, 50, 'Main Warehouse', 1),
(7, 100, 'Main Warehouse', 1),
(8, 35, 'Main Warehouse', 1),
(9, 40, 'Main Warehouse', 1),
(10, 20, 'Main Warehouse', 1);

-- Insert sample purchase orders
INSERT INTO purchase_orders (supplier_id, order_date, expected_date, status, total_amount, created_by) VALUES
(1, '2025-08-15', '2025-08-25', 'received', 16250.00, 1),
(2, '2025-08-20', '2025-08-30', 'pending', 2500.00, 2),
(3, '2025-09-01', '2025-09-10', 'approved', 4500.00, 1);

-- Insert purchase order details
INSERT INTO purchase_order_details (order_id, product_id, quantity_ordered, quantity_received, unit_cost) VALUES
(1, 1, 25, 25, 650.00),
(1, 2, 50, 50, 18.50),
(2, 4, 100, 0, 8.50),
(2, 8, 20, 0, 28.00),
(3, 5, 100, 0, 12.00),
(3, 7, 150, 0, 8.75);

-- Insert sample sales orders
INSERT INTO sales_orders (customer_name, customer_email, customer_phone, order_date, status, total_amount, created_by) VALUES
('ABC Corporation', 'orders@abccorp.com', '+1-555-1001', '2025-09-02', 'confirmed', 3599.96, 2),
('XYZ Technologies', 'procurement@xyz.com', '+1-555-1002', '2025-09-03', 'shipped', 1899.95, 3),
('Small Business Inc', 'office@smallbiz.com', '+1-555-1003', '2025-09-04', 'pending', 759.94, 2);

-- Insert sales order details
INSERT INTO sales_order_details (order_id, product_id, quantity_ordered, quantity_shipped, unit_price) VALUES
(1, 1, 4, 4, 899.99),
(2, 2, 10, 10, 29.99),
(2, 5, 20, 20, 19.99),
(2, 6, 5, 5, 149.99),
(3, 3, 2, 0, 299.99),
(3, 8, 4, 0, 45.99);

-- Insert initial stock transactions
INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, quantity_before, quantity_after, unit_cost, reference_type, reference_id, created_by) VALUES
(1, 'purchase', 25, 0, 25, 650.00, 'purchase_order', 1, 1),
(2, 'purchase', 50, 100, 150, 18.50, 'purchase_order', 1, 1),
(1, 'sale', -4, 25, 21, 650.00, 'sales_order', 1, 2),
(2, 'sale', -10, 150, 140, 18.50, 'sales_order', 2, 3),
(5, 'sale', -20, 75, 55, 12.00, 'sales_order', 2, 3);



-- ============================================================================
-- TEAM MEMBER 1: TRIGGERS IMPLEMENTATION
-- ============================================================================

-- 1. TRIGGER: Automatic inventory update when purchase order is received
CREATE TRIGGER trg_update_inventory_on_purchase
ON purchase_order_details
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Update inventory when quantity_received is updated
    IF UPDATE(quantity_received)
    BEGIN
        UPDATE i
        SET quantity_in_stock = i.quantity_in_stock + (inserted.quantity_received - deleted.quantity_received),
            last_updated = GETDATE()
        FROM inventory i
        INNER JOIN inserted ON i.product_id = inserted.product_id
        INNER JOIN deleted ON i.product_id = deleted.product_id
        WHERE inserted.quantity_received > deleted.quantity_received;

        -- Log the transaction
        INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, 
                                      quantity_before, quantity_after, unit_cost, 
                                      reference_type, reference_id, created_by)
        SELECT i.product_id, 'purchase', 
               (inserted.quantity_received - deleted.quantity_received),
               i.quantity_in_stock - (inserted.quantity_received - deleted.quantity_received),
               i.quantity_in_stock,
               inserted.unit_cost,
               'purchase_order',
               inserted.order_id,
               1 -- System user
        FROM inserted
        INNER JOIN deleted ON inserted.detail_id = deleted.detail_id
        INNER JOIN inventory i ON i.product_id = inserted.product_id
        WHERE inserted.quantity_received > deleted.quantity_received;
    END
END;

-- 2. TRIGGER: Automatic stock reduction when sales order is shipped
CREATE TRIGGER trg_reduce_stock_on_sale
ON sales_order_details
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE(quantity_shipped)
    BEGIN
        -- Check if there's enough stock
        IF EXISTS (
            SELECT 1 FROM inserted i
            INNER JOIN inventory inv ON i.product_id = inv.product_id
            WHERE (i.quantity_shipped - ISNULL((SELECT quantity_shipped FROM deleted d WHERE d.detail_id = i.detail_id), 0)) > inv.quantity_in_stock
        )
        BEGIN
            RAISERROR('Insufficient stock for the requested quantity.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END;

        -- Update inventory
        UPDATE inv
        SET quantity_in_stock = inv.quantity_in_stock - (inserted.quantity_shipped - ISNULL(deleted.quantity_shipped, 0)),
            last_updated = GETDATE()
        FROM inventory inv
        INNER JOIN inserted ON inv.product_id = inserted.product_id
        LEFT JOIN deleted ON inserted.detail_id = deleted.detail_id
        WHERE inserted.quantity_shipped > ISNULL(deleted.quantity_shipped, 0);

        -- Log the transaction
        INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, 
                                      quantity_before, quantity_after, unit_cost, 
                                      reference_type, reference_id, created_by)
        SELECT inv.product_id, 'sale', 
               -(inserted.quantity_shipped - ISNULL(deleted.quantity_shipped, 0)),
               inv.quantity_in_stock + (inserted.quantity_shipped - ISNULL(deleted.quantity_shipped, 0)),
               inv.quantity_in_stock,
               (SELECT cost_price FROM products p WHERE p.product_id = inv.product_id),
               'sales_order',
               inserted.order_id,
               1 -- System user
        FROM inserted
        LEFT JOIN deleted ON inserted.detail_id = deleted.detail_id
        INNER JOIN inventory inv ON inv.product_id = inserted.product_id
        WHERE inserted.quantity_shipped > ISNULL(deleted.quantity_shipped, 0);
    END
END;

-- 3. TRIGGER: Low stock alert trigger
CREATE TRIGGER trg_low_stock_alert
ON inventory
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Check for products that have fallen below reorder level
    IF EXISTS (
        SELECT 1 FROM inserted i
        INNER JOIN products p ON i.product_id = p.product_id
        WHERE i.quantity_in_stock <= p.reorder_level
    )
    BEGIN
        -- Log low stock alerts
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, record_id, 
                                     action_performed, new_values, timestamp)
        SELECT 1, 'LOW_STOCK_ALERT', 'inventory', i.product_id, 'SELECT',
               CONCAT('Product: ', p.product_name, ', Stock: ', i.quantity_in_stock, 
                     ', Reorder Level: ', p.reorder_level),
               GETDATE()
        FROM inserted i
        INNER JOIN products p ON i.product_id = p.product_id
        WHERE i.quantity_in_stock <= p.reorder_level;
    END
END;

-- 4. TRIGGER: Audit trail for user authentication attempts
CREATE TRIGGER trg_audit_user_login
ON users
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Log login attempts when last_login is updated
    IF UPDATE(last_login) OR UPDATE(failed_login_attempts)
    BEGIN
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, record_id, 
                                     action_performed, old_values, new_values, timestamp)
        SELECT inserted.user_id, 'LOGIN_ATTEMPT', 'users', inserted.user_id, 'UPDATE',
               CONCAT('Failed attempts: ', ISNULL(deleted.failed_login_attempts, 0)),
               CONCAT('Last login: ', inserted.last_login, ', Failed attempts: ', inserted.failed_login_attempts),
               GETDATE()
        FROM inserted
        INNER JOIN deleted ON inserted.user_id = deleted.user_id;
    END
END;

-- 5. TRIGGER: Automatic total calculation for purchase orders
CREATE TRIGGER trg_calculate_purchase_order_total
ON purchase_order_details
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- Update purchase order totals
    UPDATE po
    SET total_amount = ISNULL((
        SELECT SUM(quantity_ordered * unit_cost)
        FROM purchase_order_details pod
        WHERE pod.order_id = po.order_id
    ), 0)
    FROM purchase_orders po
    WHERE po.order_id IN (
        SELECT DISTINCT order_id FROM inserted
        UNION
        SELECT DISTINCT order_id FROM deleted
    );
END;

-- 6. TRIGGER: Automatic total calculation for sales orders
CREATE TRIGGER trg_calculate_sales_order_total
ON sales_order_details
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- Update sales order totals
    UPDATE so
    SET total_amount = ISNULL((
        SELECT SUM(quantity_ordered * unit_price)
        FROM sales_order_details sod
        WHERE sod.order_id = so.order_id
    ), 0)
    FROM sales_orders so
    WHERE so.order_id IN (
        SELECT DISTINCT order_id FROM inserted
        UNION
        SELECT DISTINCT order_id FROM deleted
    );
END;



-- ============================================================================
-- TEAM MEMBER 2: TRANSACTIONS AND ACID PROPERTIES IMPLEMENTATION
-- ============================================================================

-- 1. STORED PROCEDURE: Complete Purchase Order Transaction (Demonstrates ACID properties)
CREATE PROCEDURE sp_ProcessPurchaseOrder
    @order_id INT,
    @user_id INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON; -- Automatically rollback on error

    DECLARE @error_message NVARCHAR(500);

    BEGIN TRANSACTION PurchaseOrderTransaction;

    BEGIN TRY
        -- Atomicity: All operations must succeed or all fail

        -- 1. Validate the purchase order exists and is in pending status
        IF NOT EXISTS (SELECT 1 FROM purchase_orders WHERE order_id = @order_id AND status = 'pending')
        BEGIN
            SET @error_message = 'Purchase order not found or not in pending status';
            THROW 50001, @error_message, 1;
        END;

        -- 2. Update purchase order status to 'approved'
        UPDATE purchase_orders 
        SET status = 'approved', 
            approved_by = @user_id, 
            approved_date = GETDATE()
        WHERE order_id = @order_id;

        -- 3. For each product in the order, simulate receiving the goods
        UPDATE purchase_order_details
        SET quantity_received = quantity_ordered
        WHERE order_id = @order_id;

        -- 4. Update purchase order status to 'received'
        UPDATE purchase_orders 
        SET status = 'received'
        WHERE order_id = @order_id;

        -- 5. Log the transaction completion
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, record_id, 
                                     action_performed, new_values, timestamp)
        VALUES (@user_id, 'PURCHASE_ORDER_PROCESSED', 'purchase_orders', @order_id, 
                'UPDATE', 'Order processed and goods received', GETDATE());

        -- Consistency: All constraints and business rules are maintained
        -- Isolation: This transaction is isolated from other concurrent transactions
        -- Durability: Once committed, changes are permanent

        COMMIT TRANSACTION PurchaseOrderTransaction;

        PRINT 'Purchase order processed successfully with ACID compliance';

    END TRY
    BEGIN CATCH
        -- Rollback the entire transaction if any error occurs
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION PurchaseOrderTransaction;

        SET @error_message = ERROR_MESSAGE();
        PRINT 'Transaction rolled back due to error: ' + @error_message;
        THROW;
    END CATCH;
END;

-- 2. STORED PROCEDURE: Customer Order Processing with Inventory Check
CREATE PROCEDURE sp_ProcessCustomerOrder
    @customer_name NVARCHAR(100),
    @customer_email NVARCHAR(100),
    @customer_phone NVARCHAR(20),
    @order_items NVARCHAR(MAX), -- JSON format: [{"product_id":1,"quantity":2,"unit_price":899.99}]
    @user_id INT,
    @order_id INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @json_error NVARCHAR(500);

    BEGIN TRANSACTION CustomerOrderTransaction;

    BEGIN TRY
        -- 1. Create the sales order
        INSERT INTO sales_orders (customer_name, customer_email, customer_phone, 
                                created_by, status, order_date)
        VALUES (@customer_name, @customer_email, @customer_phone, 
                @user_id, 'pending', GETDATE());

        SET @order_id = SCOPE_IDENTITY();

        -- 2. Parse JSON and insert order details with stock validation
        INSERT INTO sales_order_details (order_id, product_id, quantity_ordered, unit_price)
        SELECT @order_id, 
               JSON_VALUE(value, '$.product_id'),
               JSON_VALUE(value, '$.quantity'),
               JSON_VALUE(value, '$.unit_price')
        FROM OPENJSON(@order_items);

        -- 3. Validate stock availability for all items
        IF EXISTS (
            SELECT 1 FROM sales_order_details sod
            INNER JOIN inventory i ON sod.product_id = i.product_id
            WHERE sod.order_id = @order_id 
            AND sod.quantity_ordered > i.quantity_in_stock
        )
        BEGIN
            DECLARE @insufficient_items NVARCHAR(MAX);
            SELECT @insufficient_items = STRING_AGG(p.product_name + ' (Available: ' + 
                   CAST(i.quantity_in_stock AS NVARCHAR) + ', Requested: ' + 
                   CAST(sod.quantity_ordered AS NVARCHAR) + ')', ', ')
            FROM sales_order_details sod
            INNER JOIN inventory i ON sod.product_id = i.product_id
            INNER JOIN products p ON sod.product_id = p.product_id
            WHERE sod.order_id = @order_id 
            AND sod.quantity_ordered > i.quantity_in_stock;

            SET @json_error = 'Insufficient stock for: ' + @insufficient_items;
            THROW 50002, @json_error, 1;
        END;

        -- 4. Reserve inventory (update reserved_quantity)
        UPDATE i
        SET reserved_quantity = i.reserved_quantity + sod.quantity_ordered
        FROM inventory i
        INNER JOIN sales_order_details sod ON i.product_id = sod.product_id
        WHERE sod.order_id = @order_id;

        -- 5. Update order status to confirmed
        UPDATE sales_orders 
        SET status = 'confirmed'
        WHERE order_id = @order_id;

        COMMIT TRANSACTION CustomerOrderTransaction;

        PRINT 'Customer order processed successfully. Order ID: ' + CAST(@order_id AS NVARCHAR);

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION CustomerOrderTransaction;

        SET @json_error = ERROR_MESSAGE();
        PRINT 'Customer order transaction failed: ' + @json_error;
        THROW;
    END CATCH;
END;

-- 3. STORED PROCEDURE: Stock Transfer Between Locations (Complex Transaction)
CREATE PROCEDURE sp_TransferStock
    @product_id INT,
    @from_location NVARCHAR(50),
    @to_location NVARCHAR(50),
    @transfer_quantity INT,
    @user_id INT,
    @notes NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @error_msg NVARCHAR(500);
    DECLARE @current_stock INT;

    BEGIN TRANSACTION StockTransferTransaction;

    BEGIN TRY
        -- 1. Check source location stock
        SELECT @current_stock = quantity_in_stock 
        FROM inventory 
        WHERE product_id = @product_id AND location = @from_location;

        IF @current_stock IS NULL
        BEGIN
            SET @error_msg = 'Product not found in source location';
            THROW 50003, @error_msg, 1;
        END;

        IF @current_stock < @transfer_quantity
        BEGIN
            SET @error_msg = 'Insufficient stock in source location. Available: ' + CAST(@current_stock AS NVARCHAR);
            THROW 50004, @error_msg, 1;
        END;

        -- 2. Reduce stock from source location
        UPDATE inventory 
        SET quantity_in_stock = quantity_in_stock - @transfer_quantity,
            last_updated = GETDATE(),
            updated_by = @user_id
        WHERE product_id = @product_id AND location = @from_location;

        -- 3. Add stock to destination location (or create new record if doesn't exist)
        IF EXISTS (SELECT 1 FROM inventory WHERE product_id = @product_id AND location = @to_location)
        BEGIN
            UPDATE inventory 
            SET quantity_in_stock = quantity_in_stock + @transfer_quantity,
                last_updated = GETDATE(),
                updated_by = @user_id
            WHERE product_id = @product_id AND location = @to_location;
        END
        ELSE
        BEGIN
            INSERT INTO inventory (product_id, quantity_in_stock, location, updated_by)
            VALUES (@product_id, @transfer_quantity, @to_location, @user_id);
        END;

        -- 4. Log both transactions
        INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, 
                                      quantity_before, quantity_after, 
                                      reference_type, notes, created_by)
        VALUES (@product_id, 'transfer', -@transfer_quantity, 
                @current_stock, @current_stock - @transfer_quantity,
                'stock_transfer', 
                'Transfer OUT to ' + @to_location + ISNULL(': ' + @notes, ''), 
                @user_id);

        INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, 
                                      quantity_before, quantity_after, 
                                      reference_type, notes, created_by)
        VALUES (@product_id, 'transfer', @transfer_quantity, 
                0, @transfer_quantity, -- Simplified for destination
                'stock_transfer', 
                'Transfer IN from ' + @from_location + ISNULL(': ' + @notes, ''), 
                @user_id);

        COMMIT TRANSACTION StockTransferTransaction;

        PRINT 'Stock transfer completed successfully';

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION StockTransferTransaction;

        SET @error_msg = ERROR_MESSAGE();
        PRINT 'Stock transfer failed: ' + @error_msg;
        THROW;
    END CATCH;
END;

-- 4. STORED PROCEDURE: Month-End Inventory Adjustment (Batch Transaction)
CREATE PROCEDURE sp_MonthEndInventoryAdjustment
    @adjustment_data NVARCHAR(MAX), -- JSON: [{"product_id":1,"actual_count":100,"adjustment_reason":"Damaged goods"}]
    @user_id INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @total_adjustments INT = 0;
    DECLARE @total_value DECIMAL(12,2) = 0;

    BEGIN TRANSACTION InventoryAdjustmentTransaction;

    BEGIN TRY
        -- Create temporary table for processing
        CREATE TABLE #AdjustmentTemp (
            product_id INT,
            actual_count INT,
            system_count INT,
            adjustment_quantity INT,
            unit_cost DECIMAL(10,2),
            adjustment_value DECIMAL(10,2),
            adjustment_reason NVARCHAR(200)
        );

        -- Parse JSON and populate temp table with calculations
        INSERT INTO #AdjustmentTemp (product_id, actual_count, adjustment_reason)
        SELECT JSON_VALUE(value, '$.product_id'),
               JSON_VALUE(value, '$.actual_count'),
               JSON_VALUE(value, '$.adjustment_reason')
        FROM OPENJSON(@adjustment_data);

        -- Calculate adjustments needed
        UPDATE #AdjustmentTemp 
        SET system_count = i.quantity_in_stock,
            adjustment_quantity = actual_count - i.quantity_in_stock,
            unit_cost = p.cost_price
        FROM #AdjustmentTemp at
        INNER JOIN inventory i ON at.product_id = i.product_id
        INNER JOIN products p ON at.product_id = p.product_id;

        UPDATE #AdjustmentTemp 
        SET adjustment_value = adjustment_quantity * unit_cost;

        -- Apply adjustments to inventory
        UPDATE i
        SET quantity_in_stock = at.actual_count,
            last_updated = GETDATE(),
            updated_by = @user_id
        FROM inventory i
        INNER JOIN #AdjustmentTemp at ON i.product_id = at.product_id
        WHERE at.adjustment_quantity != 0;

        -- Log all adjustments
        INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, 
                                      quantity_before, quantity_after, unit_cost,
                                      reference_type, notes, created_by)
        SELECT product_id, 'adjustment', adjustment_quantity,
               system_count, actual_count, unit_cost,
               'month_end_adjustment', adjustment_reason, @user_id
        FROM #AdjustmentTemp
        WHERE adjustment_quantity != 0;

        -- Get summary statistics
        SELECT @total_adjustments = COUNT(*), 
               @total_value = SUM(ABS(adjustment_value))
        FROM #AdjustmentTemp 
        WHERE adjustment_quantity != 0;

        DROP TABLE #AdjustmentTemp;

        COMMIT TRANSACTION InventoryAdjustmentTransaction;

        PRINT 'Month-end inventory adjustment completed. Items adjusted: ' + 
              CAST(@total_adjustments AS NVARCHAR) + 
              ', Total value: $' + CAST(@total_value AS NVARCHAR);

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION InventoryAdjustmentTransaction;

        IF OBJECT_ID('tempdb..#AdjustmentTemp') IS NOT NULL
            DROP TABLE #AdjustmentTemp;

        DECLARE @error_message NVARCHAR(500) = ERROR_MESSAGE();
        PRINT 'Month-end adjustment failed: ' + @error_message;
        THROW;
    END CATCH;
END;

-- 5. FUNCTION: Transaction Isolation Level Demonstration
-- This demonstrates different isolation levels and their effects

-- Example of READ COMMITTED isolation (default)
CREATE PROCEDURE sp_ReadCommittedDemo
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

    BEGIN TRANSACTION;

    -- This will only read committed data
    SELECT p.product_name, i.quantity_in_stock 
    FROM products p
    INNER JOIN inventory i ON p.product_id = i.product_id
    WHERE i.quantity_in_stock < 50;

    COMMIT TRANSACTION;
END;

-- Example of SERIALIZABLE isolation (highest level)
CREATE PROCEDURE sp_SerializableDemo
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

    BEGIN TRANSACTION;

    -- This prevents phantom reads and ensures complete isolation
    SELECT COUNT(*) as LowStockCount
    FROM inventory i
    INNER JOIN products p ON i.product_id = p.product_id
    WHERE i.quantity_in_stock <= p.reorder_level;

    -- Any other transaction trying to modify these records will be blocked

    COMMIT TRANSACTION;
END;



-- ============================================================================
-- TEAM MEMBER 3: USER AUTHENTICATION AND RESTRICTED OPERATIONS
-- ============================================================================

-- 1. USER AUTHENTICATION STORED PROCEDURE
CREATE PROCEDURE sp_AuthenticateUser
    @username NVARCHAR(50),
    @password NVARCHAR(256),
    @client_ip NVARCHAR(45) = NULL,
    @user_agent NVARCHAR(200) = NULL,
    @authentication_result INT OUTPUT, -- 0: Failed, 1: Success, 2: Account Locked
    @user_id INT OUTPUT,
    @user_role NVARCHAR(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @stored_hash NVARCHAR(256);
    DECLARE @input_hash NVARCHAR(256);
    DECLARE @failed_attempts INT;
    DECLARE @account_locked_until DATETIME;
    DECLARE @is_active BIT;

    -- Initialize output parameters
    SET @authentication_result = 0;
    SET @user_id = NULL;
    SET @user_role = NULL;

    -- Check if user exists and get details
    SELECT @user_id = user_id,
           @stored_hash = password_hash,
           @failed_attempts = failed_login_attempts,
           @account_locked_until = account_locked_until,
           @is_active = is_active,
           @user_role = role
    FROM users 
    WHERE username = @username;

    -- User not found
    IF @user_id IS NULL
    BEGIN
        -- Log failed attempt
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, user_agent, timestamp)
        VALUES (NULL, 'LOGIN_FAILED', 'users', 'SELECT', 
                'Invalid username: ' + @username, @client_ip, @user_agent, GETDATE());
        RETURN;
    END;

    -- Check if account is active
    IF @is_active = 0
    BEGIN
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, user_agent, timestamp)
        VALUES (@user_id, 'LOGIN_FAILED', 'users', 'SELECT', 
                'Account disabled', @client_ip, @user_agent, GETDATE());
        RETURN;
    END;

    -- Check if account is currently locked
    IF @account_locked_until IS NOT NULL AND @account_locked_until > GETDATE()
    BEGIN
        SET @authentication_result = 2; -- Account locked
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, user_agent, timestamp)
        VALUES (@user_id, 'LOGIN_FAILED', 'users', 'SELECT', 
                'Account locked until: ' + CAST(@account_locked_until AS NVARCHAR), 
                @client_ip, @user_agent, GETDATE());
        RETURN;
    END;

    -- Hash the input password
    SET @input_hash = CONVERT(NVARCHAR(256), HASHBYTES('SHA2_256', @password), 2);

    -- Verify password
    IF @input_hash = @stored_hash
    BEGIN
        -- Successful authentication
        SET @authentication_result = 1;

        -- Reset failed login attempts and update last login
        UPDATE users 
        SET last_login = GETDATE(),
            failed_login_attempts = 0,
            account_locked_until = NULL
        WHERE user_id = @user_id;

        -- Log successful login
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, user_agent, timestamp)
        VALUES (@user_id, 'LOGIN_SUCCESS', 'users', 'SELECT', 
                'Successful login', @client_ip, @user_agent, GETDATE());
    END
    ELSE
    BEGIN
        -- Failed authentication
        SET @failed_attempts = @failed_attempts + 1;

        -- Lock account if too many failed attempts (5 attempts = 30 min lock)
        DECLARE @lock_until DATETIME = NULL;
        IF @failed_attempts >= 5
        BEGIN
            SET @lock_until = DATEADD(MINUTE, 30, GETDATE());
        END;

        -- Update failed attempts
        UPDATE users 
        SET failed_login_attempts = @failed_attempts,
            account_locked_until = @lock_until
        WHERE user_id = @user_id;

        -- Log failed attempt
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, user_agent, timestamp)
        VALUES (@user_id, 'LOGIN_FAILED', 'users', 'SELECT', 
                'Invalid password. Attempt ' + CAST(@failed_attempts AS NVARCHAR) + 
                CASE WHEN @lock_until IS NOT NULL THEN '. Account locked.' ELSE '' END,
                @client_ip, @user_agent, GETDATE());

        IF @lock_until IS NOT NULL
        BEGIN
            SET @authentication_result = 2; -- Account now locked
        END;

        -- Clear sensitive output data
        SET @user_id = NULL;
        SET @user_role = NULL;
    END;
END;

-- 2. ROLE-BASED ACCESS CONTROL FUNCTIONS

-- Function to check if user has permission for specific operation
CREATE FUNCTION fn_CheckUserPermission
(
    @user_id INT,
    @required_role NVARCHAR(20),
    @operation NVARCHAR(50)
)
RETURNS BIT
AS
BEGIN
    DECLARE @user_role NVARCHAR(20);
    DECLARE @is_active BIT;
    DECLARE @has_permission BIT = 0;

    -- Get user role and status
    SELECT @user_role = role, @is_active = is_active
    FROM users 
    WHERE user_id = @user_id;

    -- Check if user is active
    IF @is_active != 1
        RETURN 0;

    -- Admin has all permissions
    IF @user_role = 'admin'
        SET @has_permission = 1;
    -- Manager has most permissions except user management
    ELSE IF @user_role = 'manager' AND @required_role IN ('manager', 'employee')
        SET @has_permission = 1;
    -- Employee has limited permissions
    ELSE IF @user_role = 'employee' AND @required_role = 'employee'
        SET @has_permission = 1;

    RETURN @has_permission;
END;

-- 3. RESTRICTED OPERATIONS WITH ROLE-BASED ACCESS

-- Restricted procedure: Add new user (Admin only)
CREATE PROCEDURE sp_AddUser
    @requesting_user_id INT,
    @new_username NVARCHAR(50),
    @new_password NVARCHAR(256),
    @new_email NVARCHAR(100),
    @new_role NVARCHAR(20),
    @client_ip NVARCHAR(45) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Check permissions
    IF dbo.fn_CheckUserPermission(@requesting_user_id, 'admin', 'USER_MANAGEMENT') != 1
    BEGIN
        -- Log unauthorized access attempt
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, timestamp)
        VALUES (@requesting_user_id, 'UNAUTHORIZED_ACCESS', 'users', 'INSERT', 
                'Attempted to create user without permission', @client_ip, GETDATE());

        RAISERROR('Access denied. Admin privileges required.', 16, 1);
        RETURN;
    END;

    BEGIN TRY
        -- Hash the password
        DECLARE @password_hash NVARCHAR(256);
        SET @password_hash = CONVERT(NVARCHAR(256), HASHBYTES('SHA2_256', @new_password), 2);

        -- Insert new user
        INSERT INTO users (username, password_hash, email, role)
        VALUES (@new_username, @password_hash, @new_email, @new_role);

        DECLARE @new_user_id INT = SCOPE_IDENTITY();

        -- Log user creation
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, record_id, 
                                     action_performed, new_values, ip_address, timestamp)
        VALUES (@requesting_user_id, 'USER_CREATED', 'users', @new_user_id, 'INSERT', 
                'Created user: ' + @new_username + ', Role: ' + @new_role, @client_ip, GETDATE());

        PRINT 'User created successfully. User ID: ' + CAST(@new_user_id AS NVARCHAR);

    END TRY
    BEGIN CATCH
        DECLARE @error_message NVARCHAR(500) = ERROR_MESSAGE();

        -- Log error
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, timestamp)
        VALUES (@requesting_user_id, 'USER_CREATION_FAILED', 'users', 'INSERT', 
                'Error: ' + @error_message, @client_ip, GETDATE());

        THROW;
    END CATCH;
END;

-- Restricted procedure: Delete products (Manager+ only)
CREATE PROCEDURE sp_DeleteProduct
    @requesting_user_id INT,
    @product_id INT,
    @client_ip NVARCHAR(45) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Check permissions (manager or admin can delete products)
    IF dbo.fn_CheckUserPermission(@requesting_user_id, 'manager', 'PRODUCT_DELETE') != 1
    BEGIN
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, record_id,
                                     action_performed, new_values, ip_address, timestamp)
        VALUES (@requesting_user_id, 'UNAUTHORIZED_ACCESS', 'products', @product_id, 'DELETE', 
                'Attempted to delete product without permission', @client_ip, GETDATE());

        RAISERROR('Access denied. Manager privileges required to delete products.', 16, 1);
        RETURN;
    END;

    BEGIN TRY
        DECLARE @product_name NVARCHAR(100);

        -- Get product details before deletion
        SELECT @product_name = product_name FROM products WHERE product_id = @product_id;

        IF @product_name IS NULL
        BEGIN
            RAISERROR('Product not found.', 16, 1);
            RETURN;
        END;

        -- Check if product has inventory or transactions
        IF EXISTS (SELECT 1 FROM inventory WHERE product_id = @product_id AND quantity_in_stock > 0)
        BEGIN
            RAISERROR('Cannot delete product with existing inventory.', 16, 1);
            RETURN;
        END;

        IF EXISTS (SELECT 1 FROM stock_transactions WHERE product_id = @product_id)
        BEGIN
            RAISERROR('Cannot delete product with transaction history.', 16, 1);
            RETURN;
        END;

        -- Soft delete (mark as inactive)
        UPDATE products 
        SET is_active = 0, updated_at = GETDATE()
        WHERE product_id = @product_id;

        -- Log deletion
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, record_id,
                                     action_performed, new_values, ip_address, timestamp)
        VALUES (@requesting_user_id, 'PRODUCT_DELETED', 'products', @product_id, 'UPDATE', 
                'Soft deleted product: ' + @product_name, @client_ip, GETDATE());

        PRINT 'Product soft deleted successfully: ' + @product_name;

    END TRY
    BEGIN CATCH
        DECLARE @error_message NVARCHAR(500) = ERROR_MESSAGE();

        INSERT INTO user_activity_log (user_id, activity_type, table_affected, record_id,
                                     action_performed, new_values, ip_address, timestamp)
        VALUES (@requesting_user_id, 'PRODUCT_DELETE_FAILED', 'products', @product_id, 'UPDATE', 
                'Error: ' + @error_message, @client_ip, GETDATE());

        THROW;
    END CATCH;
END;

-- Restricted procedure: View sensitive reports (Manager+ only)
CREATE PROCEDURE sp_GetFinancialReport
    @requesting_user_id INT,
    @start_date DATE,
    @end_date DATE,
    @client_ip NVARCHAR(45) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Check permissions
    IF dbo.fn_CheckUserPermission(@requesting_user_id, 'manager', 'FINANCIAL_REPORTS') != 1
    BEGIN
        INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                     new_values, ip_address, timestamp)
        VALUES (@requesting_user_id, 'UNAUTHORIZED_ACCESS', 'financial_report', 'SELECT', 
                'Attempted to access financial report without permission', @client_ip, GETDATE());

        RAISERROR('Access denied. Manager privileges required for financial reports.', 16, 1);
        RETURN;
    END;

    -- Log access to sensitive data
    INSERT INTO user_activity_log (user_id, activity_type, table_affected, action_performed, 
                                 new_values, ip_address, timestamp)
    VALUES (@requesting_user_id, 'FINANCIAL_REPORT_ACCESSED', 'financial_report', 'SELECT', 
            'Date range: ' + CAST(@start_date AS NVARCHAR) + ' to ' + CAST(@end_date AS NVARCHAR), 
            @client_ip, GETDATE());

    -- Generate financial report
    SELECT 
        'Sales Revenue' as Metric,
        SUM(total_amount) as Amount,
        COUNT(*) as TransactionCount
    FROM sales_orders 
    WHERE order_date BETWEEN @start_date AND @end_date
    AND status IN ('confirmed', 'shipped', 'delivered')

    UNION ALL

    SELECT 
        'Purchase Costs' as Metric,
        SUM(total_amount) as Amount,
        COUNT(*) as TransactionCount
    FROM purchase_orders 
    WHERE order_date BETWEEN @start_date AND @end_date
    AND status = 'received';

    -- Show inventory value
    SELECT 
        'Current Inventory Value' as Metric,
        SUM(i.quantity_in_stock * p.cost_price) as Amount,
        COUNT(*) as ProductCount
    FROM inventory i
    INNER JOIN products p ON i.product_id = p.product_id
    WHERE p.is_active = 1;
END;

-- 4. SESSION MANAGEMENT AND SECURITY

-- Procedure to check session validity
CREATE PROCEDURE sp_ValidateSession
    @user_id INT,
    @session_timeout_minutes INT = 30,
    @is_valid BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @last_activity DATETIME;

    -- Get last login time
    SELECT @last_activity = last_login
    FROM users 
    WHERE user_id = @user_id AND is_active = 1;

    -- Check if session is still valid
    IF @last_activity IS NULL OR 
       DATEDIFF(MINUTE, @last_activity, GETDATE()) > @session_timeout_minutes
    BEGIN
        SET @is_valid = 0;
    END
    ELSE
    BEGIN
        SET @is_valid = 1;

        -- Update last activity (optional - extends session)
        -- UPDATE users SET last_login = GETDATE() WHERE user_id = @user_id;
    END;
END;

-- 5. AUDIT AND COMPLIANCE PROCEDURES

-- Get user activity report
CREATE PROCEDURE sp_GetUserActivityReport
    @requesting_user_id INT,
    @target_user_id INT = NULL,
    @start_date DATETIME = NULL,
    @end_date DATETIME = NULL,
    @activity_type NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Only admins can view other users' activity
    IF @target_user_id IS NOT NULL AND @target_user_id != @requesting_user_id
    BEGIN
        IF dbo.fn_CheckUserPermission(@requesting_user_id, 'admin', 'AUDIT_REPORTS') != 1
        BEGIN
            RAISERROR('Access denied. Admin privileges required to view other users activity.', 16, 1);
            RETURN;
        END;
    END;

    -- Default to requesting user if not specified
    IF @target_user_id IS NULL
        SET @target_user_id = @requesting_user_id;

    -- Default date range (last 30 days)
    IF @start_date IS NULL
        SET @start_date = DATEADD(DAY, -30, GETDATE());
    IF @end_date IS NULL
        SET @end_date = GETDATE();

    -- Return activity log
    SELECT 
        ual.timestamp,
        u.username,
        ual.activity_type,
        ual.table_affected,
        ual.action_performed,
        ual.new_values,
        ual.ip_address
    FROM user_activity_log ual
    LEFT JOIN users u ON ual.user_id = u.user_id
    WHERE (@target_user_id IS NULL OR ual.user_id = @target_user_id)
    AND ual.timestamp BETWEEN @start_date AND @end_date
    AND (@activity_type IS NULL OR ual.activity_type = @activity_type)
    ORDER BY ual.timestamp DESC;
END;



-- ============================================================================
-- SQL EXPLAIN COMMAND EXPLORATION AND QUERY OPTIMIZATION
-- ============================================================================

-- The EXPLAIN command helps analyze query execution plans and optimize performance
-- Note: Examples shown for SQL Server, MySQL, and PostgreSQL syntax

-- ============================================================================
-- 1. BASIC EXPLAIN USAGE
-- ============================================================================

-- SQL Server Example: Simple SELECT with EXPLAIN
-- SQL Server uses "SET SHOWPLAN_ALL ON" or "SET STATISTICS IO ON"
-- For demonstration, we'll use standard SQL syntax that works across platforms

-- Example 1: Basic product search
EXPLAIN 
SELECT p.product_name, p.unit_price, c.category_name 
FROM products p
INNER JOIN categories c ON p.category_id = c.category_id
WHERE p.unit_price > 100;

-- What to look for in the execution plan:
-- - Index usage (key column)
-- - Table scans vs Index seeks
-- - Join types (nested loop, hash join, merge join)
-- - Estimated rows vs actual rows

-- ============================================================================
-- 2. INVENTORY QUERIES WITH EXPLAIN
-- ============================================================================

-- Example 2: Inventory status query
EXPLAIN
SELECT p.product_name, 
       i.quantity_in_stock,
       p.reorder_level,
       CASE 
           WHEN i.quantity_in_stock <= p.reorder_level THEN 'LOW STOCK'
           WHEN i.quantity_in_stock <= (p.reorder_level * 2) THEN 'MODERATE'
           ELSE 'SUFFICIENT'
       END as stock_status
FROM products p
INNER JOIN inventory i ON p.product_id = i.product_id
WHERE p.is_active = 1
ORDER BY i.quantity_in_stock ASC;

-- Analysis points:
-- - Check if ORDER BY is using an index
-- - Look for any table scans that could be optimized
-- - Verify join efficiency

-- Example 3: Complex query with multiple joins
EXPLAIN
SELECT p.product_name,
       SUM(pod.quantity_ordered * pod.unit_cost) as total_purchased,
       SUM(sod.quantity_ordered * sod.unit_price) as total_sold,
       i.quantity_in_stock
FROM products p
LEFT JOIN purchase_order_details pod ON p.product_id = pod.product_id
LEFT JOIN sales_order_details sod ON p.product_id = sod.product_id
INNER JOIN inventory i ON p.product_id = i.product_id
WHERE p.created_at >= '2025-01-01'
GROUP BY p.product_id, p.product_name, i.quantity_in_stock
HAVING SUM(pod.quantity_ordered * pod.unit_cost) > 1000;

-- What to analyze:
-- - How the query engine handles multiple LEFT JOINs
-- - GROUP BY performance and temporary table usage
-- - HAVING clause filtering efficiency

-- ============================================================================
-- 3. PERFORMANCE OPTIMIZATION EXAMPLES
-- ============================================================================

-- Example 4: Before optimization - Slow query
EXPLAIN
SELECT u.username, COUNT(*) as activity_count
FROM user_activity_log ual
INNER JOIN users u ON ual.user_id = u.user_id
WHERE ual.timestamp >= DATEADD(DAY, -7, GETDATE())
GROUP BY u.user_id, u.username
ORDER BY activity_count DESC;

-- Example 5: After optimization - With proper indexing
-- (This would show improved execution plan after creating indexes)
EXPLAIN
SELECT u.username, COUNT(*) as activity_count
FROM user_activity_log ual WITH (INDEX(IX_activity_log_user_date))
INNER JOIN users u ON ual.user_id = u.user_id
WHERE ual.timestamp >= DATEADD(DAY, -7, GETDATE())
GROUP BY u.user_id, u.username
ORDER BY activity_count DESC;

-- ============================================================================
-- 4. TRANSACTION-RELATED EXPLAIN EXAMPLES
-- ============================================================================

-- Example 6: Stock transaction analysis
EXPLAIN
SELECT p.product_name,
       st.transaction_type,
       SUM(st.quantity_change) as total_movement,
       AVG(st.unit_cost) as avg_cost
FROM stock_transactions st
INNER JOIN products p ON st.product_id = p.product_id
WHERE st.transaction_date >= DATEADD(MONTH, -3, GETDATE())
  AND st.transaction_type IN ('purchase', 'sale')
GROUP BY p.product_id, p.product_name, st.transaction_type;

-- ============================================================================
-- 5. SUBQUERY OPTIMIZATION EXAMPLES
-- ============================================================================

-- Example 7: Subquery that might need optimization
EXPLAIN
SELECT p.product_name, i.quantity_in_stock
FROM products p
INNER JOIN inventory i ON p.product_id = i.product_id
WHERE p.product_id IN (
    SELECT DISTINCT product_id 
    FROM stock_transactions 
    WHERE transaction_date >= DATEADD(DAY, -30, GETDATE())
);

-- Example 8: Optimized version using EXISTS
EXPLAIN
SELECT p.product_name, i.quantity_in_stock
FROM products p
INNER JOIN inventory i ON p.product_id = i.product_id
WHERE EXISTS (
    SELECT 1 
    FROM stock_transactions st
    WHERE st.product_id = p.product_id 
      AND st.transaction_date >= DATEADD(DAY, -30, GETDATE())
);

-- ============================================================================
-- 6. ADVANCED EXPLAIN FEATURES
-- ============================================================================

-- Example 9: Using EXPLAIN ANALYZE (PostgreSQL) or SET STATISTICS IO ON (SQL Server)
-- This provides actual execution statistics, not just estimates

-- PostgreSQL syntax:
-- EXPLAIN (ANALYZE, BUFFERS) 
-- SELECT * FROM products WHERE unit_price BETWEEN 50 AND 200;

-- SQL Server equivalent:
-- SET STATISTICS IO ON;
-- SET STATISTICS TIME ON;
-- SELECT * FROM products WHERE unit_price BETWEEN 50 AND 200;
-- SET STATISTICS IO OFF;
-- SET STATISTICS TIME OFF;

-- ============================================================================
-- 7. QUERY PERFORMANCE INSIGHTS
-- ============================================================================

-- Example 10: Identifying expensive operations
EXPLAIN
SELECT p.product_name,
       (SELECT COUNT(*) FROM stock_transactions st WHERE st.product_id = p.product_id) as transaction_count,
       (SELECT AVG(unit_price) FROM sales_order_details sod WHERE sod.product_id = p.product_id) as avg_sale_price,
       i.quantity_in_stock
FROM products p
INNER JOIN inventory i ON p.product_id = i.product_id
WHERE p.is_active = 1;

-- This query uses correlated subqueries which are typically expensive
-- The execution plan will show repeated executions of the subqueries

-- ============================================================================
-- 8. PRACTICAL EXPLAIN ANALYSIS GUIDELINES
-- ============================================================================

/*
KEY METRICS TO ANALYZE IN EXECUTION PLANS:

1. **Index Usage**:
   - Look for "Index Seek" vs "Table Scan" or "Index Scan"
   - Index Seek is generally more efficient
   - Multiple table scans indicate potential for optimization

2. **Join Types**:
   - Nested Loop: Good for small datasets
   - Hash Join: Good for larger datasets
   - Merge Join: Good when both inputs are sorted

3. **Estimated vs Actual Rows**:
   - Large differences indicate outdated statistics
   - Use UPDATE STATISTICS command to refresh

4. **Cost Analysis**:
   - Higher cost operations are more expensive
   - Focus optimization on highest cost operations

5. **I/O Statistics**:
   - Logical reads: Pages read from buffer cache
   - Physical reads: Pages read from disk
   - Lower numbers are better

6. **Time Statistics**:
   - Parse and compile time
   - Execution time
   - Total elapsed time

OPTIMIZATION STRATEGIES:
- Add appropriate indexes for WHERE clauses
- Use composite indexes for multi-column filters
- Avoid functions in WHERE clauses
- Use EXISTS instead of IN for subqueries
- Consider partitioning for very large tables
- Update table statistics regularly
- Use query hints sparingly and test thoroughly
*/

-- ============================================================================
-- 9. REAL-WORLD OPTIMIZATION SCENARIOS
-- ============================================================================

-- Scenario 1: Dashboard query that loads slowly
EXPLAIN
SELECT 
    (SELECT COUNT(*) FROM products WHERE is_active = 1) as active_products,
    (SELECT COUNT(*) FROM inventory WHERE quantity_in_stock <= 10) as low_stock_items,
    (SELECT COUNT(*) FROM sales_orders WHERE status = 'pending') as pending_orders,
    (SELECT SUM(total_amount) FROM sales_orders WHERE order_date >= DATEADD(DAY, -30, GETDATE())) as monthly_sales;

-- Scenario 2: Report query with complex aggregations
EXPLAIN
SELECT p.category_id,
       c.category_name,
       COUNT(DISTINCT p.product_id) as product_count,
       SUM(i.quantity_in_stock * p.cost_price) as inventory_value,
       AVG(p.unit_price) as avg_unit_price,
       MAX(st.transaction_date) as last_activity
FROM products p
INNER JOIN categories c ON p.category_id = c.category_id
INNER JOIN inventory i ON p.product_id = i.product_id
LEFT JOIN stock_transactions st ON p.product_id = st.product_id
WHERE p.is_active = 1
GROUP BY p.category_id, c.category_name;

-- ============================================================================
-- 10. MONITORING QUERY PERFORMANCE OVER TIME
-- ============================================================================

-- Create a view to help monitor slow queries
CREATE VIEW vw_query_performance_monitor AS
SELECT 
    'products_inventory_join' as query_name,
    GETDATE() as execution_time,
    (SELECT COUNT(*) FROM products p INNER JOIN inventory i ON p.product_id = i.product_id) as result_count;

-- Use this to establish baseline performance and track changes
EXPLAIN SELECT * FROM vw_query_performance_monitor;
