-- ================================================================================
-- RESEARCH COLLABORATION PORTAL - COMPLETE DATABASE IMPLEMENTATION
-- ================================================================================
-- This file contains the complete implementation of a Research Collaboration Portal
-- database including DDL, DML, advanced queries, DCL, and TCL operations.
-- 
-- Database: MySQL
-- Author: Generated from EER Diagram Design
-- ================================================================================

-- ================================================================================
-- SECTION 1: DDL (DATA DEFINITION LANGUAGE) - CREATE TABLE STATEMENTS
-- ================================================================================
-- Creating the database schema based on the EER diagram mapping.
-- Order is important to ensure foreign key references exist before they are used.

-- Create database (optional)
CREATE DATABASE IF NOT EXISTS research_portal;
USE research_portal;

-- Create Superclass Table First
CREATE TABLE Person (
    PersonID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE
);

-- Create Subclass Tables
CREATE TABLE Professor (
    PersonID INT PRIMARY KEY,
    Department VARCHAR(100) NOT NULL,
    `Rank` VARCHAR(50),
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID) ON DELETE CASCADE
);

-- Optional: More explicit PI/Co-PI specialization tables
-- (Alternative approach - the current design handles this through relationships)
/*
CREATE TABLE PI (
    PersonID INT PRIMARY KEY,
    FOREIGN KEY (PersonID) REFERENCES Professor(PersonID) ON DELETE CASCADE
);

CREATE TABLE Co_PI (
    PersonID INT PRIMARY KEY,
    FOREIGN KEY (PersonID) REFERENCES Professor(PersonID) ON DELETE CASCADE
);
*/

CREATE TABLE Student (
    PersonID INT PRIMARY KEY,
    Major VARCHAR(100) NOT NULL,
    EnrollmentDate DATE,
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID) ON DELETE CASCADE
);

-- Create Independent Entities
CREATE TABLE FundingAgency (
    AgencyID INT PRIMARY KEY AUTO_INCREMENT,
    AgencyName VARCHAR(150) NOT NULL,
    Country VARCHAR(50)
);

CREATE TABLE Project (
    ProjectID INT PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(255) NOT NULL,
    StartDate DATE,
    EndDate DATE,
    `Status` ENUM('Active', 'Completed', 'Proposed') DEFAULT 'Proposed'
);

-- Create Entity that depends on Project (1:N)
CREATE TABLE Publication (
    PublicationID INT PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(255) NOT NULL,
    Journal VARCHAR(150),
    PublicationDate DATE,
    DOI VARCHAR(100) UNIQUE,
    ProjectID INT,
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID) ON DELETE SET NULL
);

-- Create Relationship Tables
-- Ternary Relationship Table
CREATE TABLE Project_Funding (
    ProjectID INT,
    PI_ID INT,
    AgencyID INT,
    FundingAmount DECIMAL(12, 2) NOT NULL,
    PRIMARY KEY (ProjectID, PI_ID, AgencyID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID),
    FOREIGN KEY (PI_ID) REFERENCES Professor(PersonID),
    FOREIGN KEY (AgencyID) REFERENCES FundingAgency(AgencyID),
    -- Constraint from the requirements
    CONSTRAINT chk_funding CHECK (FundingAmount <= 1000000.00)
);

-- M:N Relationship for Students on Projects
CREATE TABLE Works_On (
    StudentID INT,
    ProjectID INT,
    PRIMARY KEY (StudentID, ProjectID),
    FOREIGN KEY (StudentID) REFERENCES Student(PersonID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

-- Recursive Relationship Table
CREATE TABLE Mentorship (
    MentorID INT,
    MenteeID INT,
    PRIMARY KEY (MentorID, MenteeID),
    FOREIGN KEY (MentorID) REFERENCES Professor(PersonID),
    FOREIGN KEY (MenteeID) REFERENCES Person(PersonID)
);

-- M:N Relationship for Authorship
CREATE TABLE Publication_Authors (
    PublicationID INT,
    AuthorID INT,
    PRIMARY KEY (PublicationID, AuthorID),
    FOREIGN KEY (PublicationID) REFERENCES Publication(PublicationID),
    FOREIGN KEY (AuthorID) REFERENCES Person(PersonID)
);

-- ================================================================================
-- SECTION 2: DML (DATA MANIPULATION LANGUAGE) - COMPREHENSIVE INSERT STATEMENTS
-- ================================================================================
-- Populating the created tables with extensive sample data (10+ records per table)

-- 1. Insert 20 People (Mix of Professors and Students)
INSERT INTO Person (PersonID, FirstName, LastName, Email) VALUES
(1, 'Aditya', 'Sharma', 'aditya.sharma@uni.ac.in'),
(2, 'Priya', 'Singh', 'priya.singh@uni.ac.in'),
(3, 'Rohan', 'Verma', 'rohan.v@student.uni.ac.in'),
(4, 'Ananya', 'Gupta', 'ananya.g@student.uni.ac.in'),
(5, 'Vikram', 'Rao', 'vikram.rao@uni.ac.in'),
(6, 'Sneha', 'Patel', 'sneha.patel@uni.ac.in'),
(7, 'Arjun', 'Nair', 'arjun.nair@uni.ac.in'),
(8, 'Kavya', 'Iyer', 'kavya.i@student.uni.ac.in'),
(9, 'Ravi', 'Kumar', 'ravi.kumar@uni.ac.in'),
(10, 'Meera', 'Reddy', 'meera.r@student.uni.ac.in'),
(11, 'Suresh', 'Menon', 'suresh.menon@uni.ac.in'),
(12, 'Divya', 'Shah', 'divya.s@student.uni.ac.in'),
(13, 'Karthik', 'Krishnan', 'karthik.k@student.uni.ac.in'),
(14, 'Lakshmi', 'Narayan', 'lakshmi.n@uni.ac.in'),
(15, 'Rahul', 'Agarwal', 'rahul.a@student.uni.ac.in'),
(16, 'Deepika', 'Joshi', 'deepika.joshi@uni.ac.in'),
(17, 'Akash', 'Tiwari', 'akash.t@student.uni.ac.in'),
(18, 'Nisha', 'Bansal', 'nisha.b@student.uni.ac.in'),
(19, 'Manish', 'Gupta', 'manish.gupta@uni.ac.in'),
(20, 'Pooja', 'Mishra', 'pooja.m@student.uni.ac.in');

-- 2. Insert 10 Professors (from Person table)
INSERT INTO Professor (PersonID, Department, `Rank`) VALUES
(1, 'Computer Science', 'Professor'),
(2, 'Electrical Engineering', 'Associate Professor'),
(5, 'Computer Science', 'Assistant Professor'),
(6, 'Mathematics', 'Professor'),
(7, 'Physics', 'Associate Professor'),
(9, 'Mechanical Engineering', 'Professor'),
(11, 'Chemical Engineering', 'Assistant Professor'),
(14, 'Computer Science', 'Associate Professor'),
(16, 'Electrical Engineering', 'Assistant Professor'),
(19, 'Data Science', 'Associate Professor');

-- 3. Insert 10 Students (from Person table)
INSERT INTO Student (PersonID, Major, EnrollmentDate) VALUES
(3, 'Computer Science', '2023-08-01'),
(4, 'Data Science', '2022-08-01'),
(8, 'Electrical Engineering', '2023-01-15'),
(10, 'Mathematics', '2021-08-01'),
(12, 'Computer Science', '2024-01-10'),
(13, 'Mechanical Engineering', '2022-08-01'),
(15, 'Data Science', '2023-08-01'),
(17, 'Physics', '2022-01-15'),
(18, 'Chemical Engineering', '2023-08-01'),
(20, 'Computer Science', '2024-01-10');

-- 4. Insert 10 Projects
INSERT INTO Project (ProjectID, Title, StartDate, EndDate, `Status`) VALUES
(101, 'AI in Healthcare Diagnosis', '2024-01-15', '2026-01-14', 'Active'),
(102, 'Low-Power IoT Devices', '2023-09-01', NULL, 'Active'),
(103, 'Quantum Computing Simulations', '2025-02-01', NULL, 'Proposed'),
(104, 'Smart Grid Optimization', '2023-06-01', '2025-05-31', 'Active'),
(105, 'Blockchain for Supply Chain', '2024-03-01', NULL, 'Active'),
(106, 'Advanced Materials Research', '2023-01-01', '2024-12-31', 'Completed'),
(107, 'Machine Learning for Climate', '2024-07-01', '2026-06-30', 'Active'),
(108, 'Robotics in Manufacturing', '2023-11-01', NULL, 'Active'),
(109, 'Cybersecurity Framework', '2025-01-01', NULL, 'Proposed'),
(110, 'Renewable Energy Systems', '2024-04-01', '2026-03-31', 'Active');

-- 5. Insert 10 Funding Agencies
INSERT INTO FundingAgency (AgencyID, AgencyName, Country) VALUES
(1, 'DST - SERB', 'India'),
(2, 'MeitY', 'India'),
(3, 'DRDO', 'India'),
(4, 'CSIR', 'India'),
(5, 'ISRO', 'India'),
(6, 'DBT', 'India'),
(7, 'UGC', 'India'),
(8, 'AICTE', 'India'),
(9, 'NSF', 'USA'),
(10, 'European Research Council', 'Europe');

-- 6. Insert 10+ Project Funding Records (Ternary Relationship)
INSERT INTO Project_Funding (ProjectID, PI_ID, AgencyID, FundingAmount) VALUES
(101, 1, 1, 950000.00),   -- Prof. Sharma leads AI project with DST funding
(102, 2, 2, 700000.00),   -- Prof. Singh leads IoT project with MeitY funding
(104, 6, 3, 850000.00),   -- Prof. Patel leads Smart Grid with DRDO
(105, 9, 4, 600000.00),   -- Prof. Kumar leads Blockchain with CSIR
(106, 11, 5, 900000.00),  -- Prof. Menon led Materials project with ISRO
(107, 14, 6, 750000.00),  -- Prof. Narayan leads ML Climate with DBT
(108, 16, 7, 650000.00),  -- Prof. Joshi leads Robotics with UGC
(110, 19, 8, 800000.00),  -- Prof. Gupta leads Renewable Energy with AICTE
(103, 5, 9, 980000.00),   -- Prof. Rao leads Quantum Computing with NSF
(109, 7, 10, 920000.00);  -- Prof. Nair leads Cybersecurity with ERC

-- 7. Insert 15+ Works_On Records (Students on Projects)
INSERT INTO Works_On (StudentID, ProjectID) VALUES
(3, 101),   -- Rohan on AI project
(4, 101),   -- Ananya on AI project  
(4, 102),   -- Ananya also on IoT project
(8, 102),   -- Kavya on IoT project
(8, 104),   -- Kavya also on Smart Grid
(10, 106),  -- Meera on Materials project
(12, 105),  -- Divya on Blockchain project
(12, 107),  -- Divya also on ML Climate
(13, 108),  -- Karthik on Robotics
(13, 110),  -- Karthik also on Renewable Energy
(15, 107),  -- Rahul on ML Climate
(17, 104),  -- Akash on Smart Grid
(18, 110),  -- Nisha on Renewable Energy
(20, 105),  -- Pooja on Blockchain
(20, 101);  -- Pooja also on AI project

-- 8. Insert 10+ Publications
INSERT INTO Publication (PublicationID, Title, Journal, PublicationDate, DOI, ProjectID) VALUES
(1001, 'A Novel Approach to Medical Imaging AI', 'Journal of Medical AI', '2025-05-20', '10.1000/jmai.2025.1', 101),
(1002, 'Efficient Power Management in IoT', 'IEEE Transactions on IoT', '2024-11-10', '10.1109/TIE.2024.2', 102),
(1003, 'Smart Grid Optimization Using ML', 'Energy Systems Journal', '2024-08-15', '10.1016/esj.2024.1', 104),
(1004, 'Blockchain Applications in Supply Chain', 'Blockchain Technology Review', '2024-12-01', '10.1007/btr.2024.3', 105),
(1005, 'Advanced Composite Materials', 'Materials Science Today', '2024-06-30', '10.1038/mst.2024.5', 106),
(1006, 'Climate Prediction Models', 'Nature Climate Change', '2025-03-15', '10.1038/ncc.2025.1', 107),
(1007, 'Robotic Process Automation', 'IEEE Robotics & Automation', '2024-09-20', '10.1109/ra.2024.4', 108),
(1008, 'Renewable Energy Integration', 'Renewable Energy Journal', '2024-10-05', '10.1016/rej.2024.7', 110),
(1009, 'Deep Learning in Healthcare', 'AI in Medicine', '2025-01-12', '10.1016/aim.2025.2', 101),
(1010, 'IoT Security Frameworks', 'Security and Communication', '2024-07-25', '10.1002/sec.2024.6', 102);

-- 9. Insert 20+ Publication Authors (Many-to-Many relationship)
INSERT INTO Publication_Authors (PublicationID, AuthorID) VALUES
(1001, 1),   -- Prof. Sharma on AI paper
(1001, 3),   -- Student Rohan on AI paper
(1001, 4),   -- Student Ananya on AI paper
(1002, 2),   -- Prof. Singh on IoT paper
(1002, 8),   -- Student Kavya on IoT paper
(1003, 6),   -- Prof. Patel on Smart Grid paper
(1003, 8),   -- Student Kavya on Smart Grid paper
(1003, 17),  -- Student Akash on Smart Grid paper
(1004, 9),   -- Prof. Kumar on Blockchain paper
(1004, 12),  -- Student Divya on Blockchain paper
(1004, 20),  -- Student Pooja on Blockchain paper
(1005, 11),  -- Prof. Menon on Materials paper
(1005, 10),  -- Student Meera on Materials paper
(1006, 14),  -- Prof. Narayan on Climate paper
(1006, 12),  -- Student Divya on Climate paper
(1006, 15),  -- Student Rahul on Climate paper
(1007, 16),  -- Prof. Joshi on Robotics paper
(1007, 13),  -- Student Karthik on Robotics paper
(1008, 19),  -- Prof. Gupta on Renewable Energy paper
(1008, 13),  -- Student Karthik on Renewable Energy paper
(1008, 18),  -- Student Nisha on Renewable Energy paper
(1009, 1),   -- Prof. Sharma on second AI paper
(1009, 20),  -- Student Pooja on second AI paper
(1010, 2),   -- Prof. Singh on IoT Security paper
(1010, 4);   -- Student Ananya on IoT Security paper

-- 10. Insert 15+ Mentorship Records (Recursive Relationship)
INSERT INTO Mentorship (MentorID, MenteeID) VALUES
(1, 5),    -- Prof. Sharma mentors Prof. Rao (junior faculty)
(1, 4),    -- Prof. Sharma mentors student Ananya
(1, 3),    -- Prof. Sharma mentors student Rohan
(2, 16),   -- Prof. Singh mentors Prof. Joshi (junior faculty)
(2, 8),    -- Prof. Singh mentors student Kavya
(6, 11),   -- Prof. Patel mentors Prof. Menon (junior faculty)
(6, 10),   -- Prof. Patel mentors student Meera
(9, 14),   -- Prof. Kumar mentors Prof. Narayan
(9, 12),   -- Prof. Kumar mentors student Divya
(9, 13),   -- Prof. Kumar mentors student Karthik
(7, 17),   -- Prof. Nair mentors student Akash
(11, 18),  -- Prof. Menon mentors student Nisha
(14, 15),  -- Prof. Narayan mentors student Rahul
(16, 20),  -- Prof. Joshi mentors student Pooja
(19, 8);   -- Prof. Gupta mentors student Kavya (co-mentoring)

-- ================================================================================
-- SECTION 3: ADVANCED QUERIES - AGGREGATE FUNCTIONS
-- ================================================================================
-- Queries demonstrating the use of aggregate functions, GROUP BY, and HAVING

-- Query 1: Find the total funding for each PI and list only those whose total funding exceeds ₹8,00,000.
-- This uses SUM(), GROUP BY, and HAVING.
SELECT
    p.FirstName,
    p.LastName,
    SUM(pf.FundingAmount) AS TotalFunding
FROM Person p
JOIN Professor pr ON p.PersonID = pr.PersonID
JOIN Project_Funding pf ON pr.PersonID = pf.PI_ID
GROUP BY p.PersonID, p.FirstName, p.LastName
HAVING TotalFunding > 800000.00;

-- Query 2: Count the number of active projects per department.
-- This uses COUNT(), GROUP BY, and a WHERE clause.
SELECT
    pr.Department,
    COUNT(proj.ProjectID) AS NumberOfActiveProjects
FROM Project proj
JOIN Project_Funding pf ON proj.ProjectID = pf.ProjectID
JOIN Professor pr ON pf.PI_ID = pr.PersonID
WHERE proj.Status = 'Active'
GROUP BY pr.Department
ORDER BY NumberOfActiveProjects DESC;

-- Query 3: Find the average, maximum, and minimum funding provided by each funding agency.
-- This uses AVG(), MAX(), and MIN().
SELECT
    fa.AgencyName,
    AVG(pf.FundingAmount) AS AverageFunding,
    MAX(pf.FundingAmount) AS MaximumGrant,
    MIN(pf.FundingAmount) AS MinimumGrant
FROM FundingAgency fa
JOIN Project_Funding pf ON fa.AgencyID = pf.AgencyID
GROUP BY fa.AgencyName;

-- ================================================================================
-- SECTION 4: ADVANCED QUERIES - NESTED SUBQUERIES
-- ================================================================================
-- Subqueries allow complex, multi-step logical queries

-- Query 4: Find projects with funding greater than the overall average funding amount.
-- This uses a scalar subquery in the WHERE clause.
SELECT
    p.Title,
    pf.FundingAmount
FROM Project p
JOIN Project_Funding pf ON p.ProjectID = pf.ProjectID
WHERE pf.FundingAmount > (SELECT AVG(FundingAmount) FROM Project_Funding);

-- Query 5: Find the names of all students working on projects led by 'Aditya Sharma'.
-- This uses a multi-row subquery with the IN operator.
SELECT
    p.FirstName,
    p.LastName
FROM Person p
JOIN Student s ON p.PersonID = s.PersonID
WHERE s.PersonID IN (
    SELECT wo.StudentID
    FROM Works_On wo
    WHERE wo.ProjectID IN (
        SELECT ProjectID FROM Project_Funding WHERE PI_ID = (
            SELECT PersonID FROM Person WHERE FirstName = 'Aditya' AND LastName = 'Sharma'
        )
    )
);

-- Query 6: Find all professors who are NOT currently a PI on any active project.
-- This uses a correlated subquery with the NOT EXISTS operator.
SELECT
    p.FirstName,
    p.LastName
FROM Person p
JOIN Professor pr ON p.PersonID = pr.PersonID
WHERE NOT EXISTS (
    SELECT 1
    FROM Project_Funding pf
    JOIN Project proj ON pf.ProjectID = proj.ProjectID
    WHERE pf.PI_ID = pr.PersonID AND proj.Status = 'Active'
);

-- ================================================================================
-- SECTION 5: ADVANCED QUERIES - WINDOW FUNCTIONS
-- ================================================================================
-- Window functions perform calculations across related rows

-- Query 7: Rank professors based on their total funding amount.
-- This uses the RANK() window function.
SELECT
    p.FirstName,
    p.LastName,
    SUM(pf.FundingAmount) AS TotalFunding,
    RANK() OVER (ORDER BY SUM(pf.FundingAmount) DESC) AS FundingRank
FROM Person p
JOIN Professor pr ON p.PersonID = pr.PersonID
JOIN Project_Funding pf ON pr.PersonID = pf.PI_ID
GROUP BY p.PersonID, p.FirstName, p.LastName;

-- Query 8: For each department, assign a unique row number to each professor based on their PersonID.
-- This uses the ROW_NUMBER() window function partitioned by department.
SELECT
    p.FirstName,
    p.LastName,
    pr.Department,
    ROW_NUMBER() OVER (PARTITION BY pr.Department ORDER BY p.PersonID) AS ProfessorNumberInDept
FROM Person p
JOIN Professor pr ON p.PersonID = pr.PersonID;

-- Query 9: List all publications and show the title of the next publication within the same project based on date.
-- This uses the LEAD() window function to fetch data from a subsequent row.
SELECT
    p.Title AS PublicationTitle,
    proj.Title AS ProjectTitle,
    p.PublicationDate,
    LEAD(p.Title, 1, 'No Subsequent Publication') OVER (PARTITION BY p.ProjectID ORDER BY p.PublicationDate) AS NextPublication
FROM Publication p
JOIN Project proj ON p.ProjectID = proj.ProjectID;

-- ================================================================================
-- SECTION 6: ADVANCED QUERIES - JOIN OPERATIONS
-- ================================================================================
-- Demonstrating various types of JOIN operations

-- Query 10: INNER JOIN (also an Equi Join)
-- Retrieve the names of professors and the titles of the 'Active' projects they lead as a PI.
SELECT
    p.FirstName,
    p.LastName,
    proj.Title AS ProjectTitle
FROM Person p
INNER JOIN Professor pr ON p.PersonID = pr.PersonID
INNER JOIN Project_Funding pf ON pr.PersonID = pf.PI_ID
INNER JOIN Project proj ON pf.ProjectID = proj.ProjectID
WHERE proj.Status = 'Active';

-- Query 11: LEFT OUTER JOIN
-- List ALL professors and, if they are a PI on a project, the project's title.
SELECT
    p.FirstName,
    p.LastName,
    proj.Title AS ProjectTitle
FROM Person p
JOIN Professor pr ON p.PersonID = pr.PersonID
LEFT JOIN Project_Funding pf ON pr.PersonID = pf.PI_ID
LEFT JOIN Project proj ON pf.ProjectID = proj.ProjectID;

-- Query 12: RIGHT OUTER JOIN
-- List ALL projects and the name of their PI.
SELECT
    p.FirstName AS PI_FirstName,
    p.LastName AS PI_LastName,
    proj.Title,
    proj.Status
FROM Person p
JOIN Professor pr ON p.PersonID = pr.PersonID
RIGHT JOIN Project_Funding pf ON pr.PersonID = pf.PI_ID
RIGHT JOIN Project proj ON pf.ProjectID = proj.ProjectID;

-- Query 13: FULL OUTER JOIN (Simulated in MySQL)
-- List all students and all active projects, matching them where a student works on a project.
-- Students working on active projects
SELECT s.PersonID, p.Title
FROM Student s
LEFT JOIN Works_On wo ON s.PersonID = wo.StudentID
LEFT JOIN Project p ON wo.ProjectID = p.ProjectID AND p.Status = 'Active'
UNION
-- Active projects with assigned students
SELECT s.PersonID, p.Title
FROM Student s
RIGHT JOIN Works_On wo ON s.PersonID = wo.StudentID
RIGHT JOIN Project p ON wo.ProjectID = p.ProjectID AND p.Status = 'Active';

-- Query 14: CROSS JOIN
-- Generate a Cartesian product of every possible pairing between a student and a funding agency.
SELECT
    p.FirstName,
    p.LastName,
    fa.AgencyName
FROM Person p
JOIN Student s ON p.PersonID = s.PersonID
CROSS JOIN FundingAgency fa;

-- Query 15: NATURAL JOIN
-- List the names of professors and their departmental info.
SELECT
    FirstName,
    LastName,
    Department,
    `Rank`
FROM Person
NATURAL JOIN Professor;

-- Query 16: SELF JOIN
-- Find pairs of professors who are in the same department.
SELECT
    p1.FirstName AS Professor1_FirstName,
    p1.LastName AS Professor1_LastName,
    p2.FirstName AS Professor2_FirstName,
    p2.LastName AS Professor2_LastName,
    prof1.Department
FROM Professor prof1
JOIN Professor prof2 ON prof1.Department = prof2.Department AND prof1.PersonID < prof2.PersonID
JOIN Person p1 ON prof1.PersonID = p1.PersonID
JOIN Person p2 ON prof2.PersonID = p2.PersonID;

-- Query 17: NON-EQUI JOIN
-- Find projects that were started within 180 days of each other.
SELECT
    p1.Title AS Project1,
    p1.StartDate AS Project1_Start,
    p2.Title AS Project2,
    p2.StartDate AS Project2_Start
FROM Project p1
JOIN Project p2 ON p1.ProjectID <> p2.ProjectID
    AND p2.StartDate BETWEEN p1.StartDate AND DATE_ADD(p1.StartDate, INTERVAL 180 DAY);

-- Query 18: SEMI JOIN (using EXISTS)
-- Retrieve all students who are working on at least one 'Active' project.
SELECT
    p.FirstName,
    p.LastName
FROM Person p
WHERE p.PersonID IN (SELECT PersonID FROM Student)
AND EXISTS (
    SELECT 1
    FROM Works_On wo
    JOIN Project proj ON wo.ProjectID = proj.ProjectID
    WHERE wo.StudentID = p.PersonID AND proj.Status = 'Active'
);

-- Query 19: ANTI JOIN (using NOT EXISTS)
-- Find all professors who are not mentoring anyone (neither students nor other professors).
SELECT
    p.FirstName,
    p.LastName
FROM Person p
JOIN Professor pr ON p.PersonID = pr.PersonID
WHERE NOT EXISTS (
    SELECT 1
    FROM Mentorship m
    WHERE m.MentorID = pr.PersonID
);

-- ================================================================================
-- SECTION 7: DCL (DATA CONTROL LANGUAGE) - USER MANAGEMENT & PERMISSIONS
-- ================================================================================
-- Managing access rights and permissions in the database

-- Create users first (requires administrative privileges)
CREATE USER 'head_of_cs'@'localhost' IDENTIFIED BY 'secure_password_123';
CREATE USER 'research_asst'@'localhost' IDENTIFIED BY 'simple_password_456';

-- GRANT Commands
-- Grant broad permissions to the 'department_head'
GRANT SELECT, INSERT, UPDATE ON research_portal.Professor TO 'head_of_cs'@'localhost';
GRANT SELECT, INSERT, UPDATE ON research_portal.Project TO 'head_of_cs'@'localhost';
-- They only get read access to publications.
GRANT SELECT ON research_portal.Publication TO 'head_of_cs'@'localhost';

-- Grant limited, read-only permissions to the 'research_assistant'
GRANT SELECT ON research_portal.Project TO 'research_asst'@'localhost';
GRANT SELECT ON research_portal.Publication TO 'research_asst'@'localhost';

-- Verify the grants
SHOW GRANTS FOR 'head_of_cs'@'localhost';

-- REVOKE Commands
-- Revoke the INSERT privilege on the Project table from the department head.
REVOKE INSERT ON research_portal.Project FROM 'head_of_cs'@'localhost';

-- Revoke all privileges for the research assistant on the Publication table.
REVOKE ALL PRIVILEGES ON research_portal.Publication FROM 'research_asst'@'localhost';

-- Verify the privileges have been removed
SHOW GRANTS FOR 'head_of_cs'@'localhost';

-- ================================================================================
-- SECTION 8: TCL (TRANSACTION CONTROL LANGUAGE) - TRANSACTION MANAGEMENT
-- ================================================================================
-- Managing transactions to ensure ACID properties

-- Example 1: COMMIT and ROLLBACK
-- Adding a new publication with authors - both steps must succeed
START TRANSACTION;

-- Step 1: Insert a new publication for Project 102
INSERT INTO Publication (PublicationID, Title, Journal, PublicationDate, DOI, ProjectID)
VALUES (1002, 'Efficient Power Management in IoT', 'IEEE Transactions', '2025-11-10', '10.1109/TIE.2025.2', 102);

-- Step 2: Add the authors (Professor Singh and Student Gupta) to the new publication
INSERT INTO Publication_Authors (PublicationID, AuthorID) VALUES (1002, 2);
INSERT INTO Publication_Authors (PublicationID, AuthorID) VALUES (1002, 4);

-- Everything is correct - make changes permanent
COMMIT;

-- Example 2: ROLLBACK for accidental deletion
START TRANSACTION;

-- Accidentally delete a funding record
DELETE FROM Project_Funding WHERE ProjectID = 101;

-- Realize the mistake! Undo the deletion before committing
ROLLBACK;

-- Check that the record is still there
SELECT * FROM Project_Funding WHERE ProjectID = 101;

-- Example 3: SAVEPOINT for partial rollback
-- Multi-step project allocation with selective rollback
START TRANSACTION;

-- Step 1: Update the 'Proposed' project to 'Active'
UPDATE Project SET Status = 'Active', StartDate = CURDATE() WHERE ProjectID = 103;

-- Create a bookmark after project activation
SAVEPOINT project_activated;

-- Step 2: Assign PI Vikram Rao (5) and funding agency MeitY (2)
INSERT INTO Project_Funding (ProjectID, PI_ID, AgencyID, FundingAmount)
VALUES (103, 5, 2, 800000.00);

-- Create another bookmark after funding assignment
SAVEPOINT funding_assigned;

-- Step 3: If student assignment fails (business logic check)
-- We can roll back to just before the student assignment
-- This preserves the project activation and funding assignment
ROLLBACK TO SAVEPOINT funding_assigned;

-- Commit the partial progress (project active and funded, but no student assigned)
COMMIT;

-- Verify the final state
SELECT * FROM Project WHERE ProjectID = 103; -- Status is 'Active'
SELECT * FROM Project_Funding WHERE ProjectID = 103; -- PI and funding are assigned
SELECT * FROM Works_On WHERE ProjectID = 103; -- No student is assigned

-- ================================================================================
-- SECTION 9: ADDITIONAL BUSINESS LOGIC CONSTRAINTS
-- ================================================================================
-- Note: The constraint "A student cannot be on more than 2 active projects" 
-- would typically be enforced through application logic or triggers, as MySQL 
-- doesn't support complex CHECK constraints involving other tables.

-- Example trigger to enforce the student project limit constraint:
DELIMITER //
CREATE TRIGGER check_student_project_limit 
BEFORE INSERT ON Works_On
FOR EACH ROW
BEGIN
    DECLARE active_project_count INT;
    
    SELECT COUNT(*) INTO active_project_count
    FROM Works_On wo
    JOIN Project p ON wo.ProjectID = p.ProjectID
    WHERE wo.StudentID = NEW.StudentID AND p.Status = 'Active';
    
    IF active_project_count >= 2 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Student cannot be assigned to more than 2 active projects';
    END IF;
END//
DELIMITER ;

-- ================================================================================
-- END OF RESEARCH COLLABORATION PORTAL DATABASE IMPLEMENTATION
-- ================================================================================