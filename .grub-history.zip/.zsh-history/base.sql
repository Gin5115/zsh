-- ============================================================================
-- SQL & MySQL COMPREHENSIVE CHEAT SHEET
-- For DBMS Lab Assignments & Exam Preparation
-- ============================================================================

-- ============================================================================
-- PART 1: DATA DEFINITION LANGUAGE (DDL)
-- ============================================================================

-- CREATE DATABASE
CREATE DATABASE ResearchPortal;
USE ResearchPortal;

-- CREATE TABLES with Constraints
CREATE TABLE Professors (
    ProfessorID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100) NOT NULL,
    Designation VARCHAR(50),
    Department VARCHAR(100),
    Email VARCHAR(100) UNIQUE,
    HireDate DATE
);

CREATE TABLE Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100) NOT NULL,
    Department VARCHAR(100),
    City VARCHAR(50),
    Email VARCHAR(100) UNIQUE,
    EnrollmentDate DATE
);

CREATE TABLE Projects (
    ProjectID INT PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(200) NOT NULL,
    StartDate DATE,
    EndDate DATE,
    TotalFunding DECIMAL(12,2) DEFAULT 0,
    SupervisorID INT,
    FOREIGN KEY (SupervisorID) REFERENCES Professors(ProfessorID),
    CONSTRAINT chk_funding CHECK (TotalFunding <= 1000000)
);

CREATE TABLE Publications (
    PublicationID INT PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(300) NOT NULL,
    PublicationYear YEAR,
    ProjectID INT,
    AuthorType ENUM('Student', 'Professor', 'Both'),
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID) ON DELETE CASCADE
);

CREATE TABLE FundingAgencies (
    AgencyID INT PRIMARY KEY AUTO_INCREMENT,
    AgencyName VARCHAR(150) NOT NULL,
    Country VARCHAR(50),
    Type VARCHAR(50)
);

-- JUNCTION TABLES (Many-to-Many Relationships)
CREATE TABLE Project_Student (
    ProjectID INT,
    StudentID INT,
    ParticipationType ENUM('Full', 'Partial') DEFAULT 'Full',
    PRIMARY KEY (ProjectID, StudentID),
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID)
);

CREATE TABLE Project_Funding (
    ProjectID INT,
    AgencyID INT,
    FundingAmount DECIMAL(12,2),
    FundingDate DATE,
    PRIMARY KEY (ProjectID, AgencyID),
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID),
    FOREIGN KEY (AgencyID) REFERENCES FundingAgencies(AgencyID)
);

-- ALTER TABLE
ALTER TABLE Professors ADD COLUMN Phone VARCHAR(15);
ALTER TABLE Students MODIFY COLUMN City VARCHAR(100);
ALTER TABLE Projects ADD CONSTRAINT chk_dates CHECK (EndDate > StartDate);

-- DROP and TRUNCATE
-- DROP TABLE TableName; -- Deletes entire table structure
-- TRUNCATE TABLE TableName; -- Deletes all rows but keeps structure

-- ============================================================================
-- PART 2: DATA MANIPULATION LANGUAGE (DML)
-- ============================================================================

-- INSERT DATA (at least 20 records per table as per assignment)
INSERT INTO Professors (Name, Designation, Department, Email, HireDate) VALUES
('Dr. John Smith', 'Professor', 'Computer Science', 'john@university.edu', '2010-08-15'),
('Dr. Sarah Johnson', 'Associate Professor', 'Computer Science', 'sarah@university.edu', '2012-09-01'),
('Dr. Michael Brown', 'Assistant Professor', 'Data Science', 'michael@university.edu', '2015-01-20'),
('Dr. Emily Davis', 'Professor', 'Information Technology', 'emily@university.edu', '2008-07-10'),
('Dr. Robert Wilson', 'Associate Professor', 'Computer Science', 'robert@university.edu', '2013-03-15'),
('Dr. Lisa Anderson', 'Professor', 'Artificial Intelligence', 'lisa@university.edu', '2009-11-22'),
('Dr. James Taylor', 'Assistant Professor', 'Computer Science', 'james@university.edu', '2016-05-30'),
('Dr. Maria Garcia', 'Associate Professor', 'Data Science', 'maria@university.edu', '2014-02-18'),
('Dr. David Martinez', 'Professor', 'Computer Science', 'david@university.edu', '2007-06-12'),
('Dr. Jennifer Lopez', 'Assistant Professor', 'Information Technology', 'jennifer@university.edu', '2017-09-05'),
('Dr. Christopher Lee', 'Professor', 'Computer Science', 'chris@university.edu', '2006-04-20'),
('Dr. Amanda White', 'Associate Professor', 'Data Science', 'amanda@university.edu', '2011-12-08'),
('Dr. Matthew Harris', 'Assistant Professor', 'Computer Science', 'matthew@university.edu', '2018-01-15'),
('Dr. Jessica Clark', 'Professor', 'Artificial Intelligence', 'jessica@university.edu', '2005-10-30'),
('Dr. Daniel Lewis', 'Associate Professor', 'Computer Science', 'daniel@university.edu', '2013-08-25'),
('Dr. Ashley Walker', 'Assistant Professor', 'Information Technology', 'ashley@university.edu', '2019-03-10'),
('Dr. Joshua Hall', 'Professor', 'Data Science', 'joshua@university.edu', '2008-11-18'),
('Dr. Stephanie Allen', 'Associate Professor', 'Computer Science', 'stephanie@university.edu', '2014-07-22'),
('Dr. Ryan Young', 'Assistant Professor', 'Artificial Intelligence', 'ryan@university.edu', '2017-04-12'),
('Dr. Michelle King', 'Professor', 'Computer Science', 'michelle@university.edu', '2006-09-28');

INSERT INTO Students (Name, Department, City, Email, EnrollmentDate) VALUES
('Alice Johnson', 'Computer Science', 'New York', 'alice@student.edu', '2020-09-01'),
('Bob Smith', 'Data Science', 'Boston', 'bob@student.edu', '2020-09-01'),
('Charlie Brown', 'Computer Science', 'Chicago', 'charlie@student.edu', '2021-01-15'),
('Diana Prince', 'Information Technology', 'Los Angeles', 'diana@student.edu', '2019-09-01'),
('Eve Davis', 'Computer Science', 'San Francisco', 'eve@student.edu', '2020-09-01'),
('Frank Miller', 'Data Science', 'Seattle', 'frank@student.edu', '2021-09-01'),
('Grace Lee', 'Computer Science', 'Austin', 'grace@student.edu', '2020-01-10'),
('Henry Wilson', 'Artificial Intelligence', 'Denver', 'henry@student.edu', '2019-09-01'),
('Ivy Chen', 'Computer Science', 'Portland', 'ivy@student.edu', '2021-01-15'),
('Jack Thompson', 'Data Science', 'Miami', 'jack@student.edu', '2020-09-01'),
('Karen White', 'Computer Science', 'Atlanta', 'karen@student.edu', '2019-09-01'),
('Leo Martinez', 'Information Technology', 'Dallas', 'leo@student.edu', '2021-09-01'),
('Mia Anderson', 'Computer Science', 'Phoenix', 'mia@student.edu', '2020-09-01'),
('Nathan Garcia', 'Data Science', 'San Diego', 'nathan@student.edu', '2020-01-10'),
('Olivia Rodriguez', 'Computer Science', 'Philadelphia', 'olivia@student.edu', '2021-01-15'),
('Paul Kim', 'Artificial Intelligence', 'Houston', 'paul@student.edu', '2019-09-01'),
('Quinn Taylor', 'Computer Science', 'Columbus', 'quinn@student.edu', '2020-09-01'),
('Rachel Moore', 'Data Science', 'Indianapolis', 'rachel@student.edu', '2021-09-01'),
('Sam Jackson', 'Computer Science', 'Charlotte', 'sam@student.edu', '2020-01-10'),
('Tina Brown', 'Information Technology', 'Detroit', 'tina@student.edu', '2019-09-01');

INSERT INTO Projects (Title, StartDate, EndDate, TotalFunding, SupervisorID) VALUES
('AI-Powered Healthcare System', '2021-01-15', '2023-12-31', 850000.00, 1),
('Blockchain for Supply Chain', '2020-06-01', '2023-05-30', 620000.00, 2),
('Machine Learning in Finance', '2021-09-01', '2024-08-31', 750000.00, 3),
('IoT Security Framework', '2020-03-15', '2023-02-28', 480000.00, 4),
('Natural Language Processing', '2021-05-01', '2024-04-30', 920000.00, 5),
('Computer Vision for Robotics', '2020-11-01', '2023-10-31', 680000.00, 6),
('Cloud Computing Optimization', '2021-02-15', '2023-12-15', 550000.00, 7),
('Big Data Analytics Platform', '2020-08-01', '2023-07-31', 800000.00, 8),
('Cybersecurity in Smart Cities', '2021-04-01', '2024-03-31', 710000.00, 9),
('Quantum Computing Algorithms', '2020-10-15', '2023-09-30', 950000.00, 10),
('Deep Learning for Image Analysis', '2021-07-01', '2024-06-30', 630000.00, 11),
('Augmented Reality Applications', '2020-12-01', '2023-11-30', 520000.00, 12),
('Edge Computing Solutions', '2021-03-15', '2024-02-29', 670000.00, 13),
('Bioinformatics Data Mining', '2020-05-01', '2023-04-30', 780000.00, 14),
('Smart Grid Technology', '2021-06-15', '2024-05-31', 840000.00, 15),
('Virtual Reality Training', '2020-09-01', '2023-08-31', 490000.00, 16),
('Automated Testing Framework', '2021-08-01', '2024-07-31', 410000.00, 17),
('Data Privacy Mechanisms', '2020-07-15', '2023-06-30', 720000.00, 18),
('Distributed Systems Research', '2021-10-01', '2024-09-30', 580000.00, 19),
('Neural Networks Optimization', '2020-04-01', '2023-03-31', 890000.00, 20);

INSERT INTO FundingAgencies (AgencyName, Country, Type) VALUES
('National Science Foundation', 'USA', 'Government'),
('European Research Council', 'Germany', 'International'),
('Department of Defense', 'USA', 'Government'),
('Google Research', 'USA', 'Private'),
('Microsoft Research', 'USA', 'Private'),
('IBM Research', 'USA', 'Private'),
('National Institutes of Health', 'USA', 'Government'),
('DARPA', 'USA', 'Government'),
('Amazon Web Services', 'USA', 'Private'),
('Intel Corporation', 'USA', 'Private'),
('NASA', 'USA', 'Government'),
('Meta Research', 'USA', 'Private'),
('Apple Inc', 'USA', 'Private'),
('Samsung Electronics', 'South Korea', 'Private'),
('Siemens AG', 'Germany', 'Private'),
('Toyota Research', 'Japan', 'Private'),
('Deutsche Forschungsgemeinschaft', 'Germany', 'Government'),
('UK Research and Innovation', 'United Kingdom', 'Government'),
('Canadian Institutes of Health', 'Canada', 'Government'),
('Chinese Academy of Sciences', 'China', 'Government');

-- UPDATE
UPDATE Projects 
SET TotalFunding = 900000.00 
WHERE ProjectID = 1;

UPDATE Professors 
SET Designation = 'Professor' 
WHERE Name = 'Dr. Sarah Johnson';

-- DELETE
DELETE FROM Publications WHERE PublicationYear < 2015;

-- ============================================================================
-- PART 3: TRANSACTION CONTROL LANGUAGE (TCL)
-- ============================================================================

-- TRANSACTION EXAMPLE
START TRANSACTION;

UPDATE Projects 
SET TotalFunding = TotalFunding + 50000 
WHERE ProjectID = 5;

INSERT INTO Project_Funding (ProjectID, AgencyID, FundingAmount, FundingDate)
VALUES (5, 1, 50000, '2023-06-15');

-- Check if everything is correct
SELECT TotalFunding FROM Projects WHERE ProjectID = 5;

-- If satisfied, commit the transaction
COMMIT;

-- If there's an error, rollback
-- ROLLBACK;

-- SAVEPOINT EXAMPLE
START TRANSACTION;

SAVEPOINT before_update;

UPDATE Projects SET TotalFunding = 1000000 WHERE ProjectID = 10;

-- If something goes wrong, rollback to savepoint
ROLLBACK TO SAVEPOINT before_update;

COMMIT;

-- ============================================================================
-- PART 4: DATA CONTROL LANGUAGE (DCL)
-- ============================================================================

-- GRANT privileges
GRANT SELECT, INSERT, UPDATE ON ResearchPortal.* TO 'student_user'@'localhost';
GRANT ALL PRIVILEGES ON ResearchPortal.Projects TO 'admin_user'@'localhost';

-- REVOKE privileges
REVOKE INSERT, UPDATE ON ResearchPortal.* FROM 'student_user'@'localhost';

-- Create users (authentication)
CREATE USER 'readonly_user'@'localhost' IDENTIFIED BY 'password123';
CREATE USER 'dataentry_user'@'%' IDENTIFIED BY 'password456';

-- ============================================================================
-- PART 5: DATA QUERY LANGUAGE (DQL) - SELECT STATEMENTS
-- ============================================================================

-- Q1.1: Count total customers (using variable)
SELECT COUNT(*) INTO @count FROM Students;
SELECT @count AS TotalCustomers;

-- Q1.2: Number of students from each city, sorted by highest count
SELECT City, COUNT(*) AS StudentCount
FROM Students
GROUP BY City
ORDER BY StudentCount DESC;

-- Q2.1: Top 5 projects based on highest funding
SELECT ProjectID, Title, TotalFunding
FROM Projects
ORDER BY TotalFunding DESC
LIMIT 5;

-- Q2.2: All projects supervised by professor ID 5, sorted by date
SELECT *
FROM Projects
WHERE SupervisorID = 5
ORDER BY StartDate DESC;

-- Q2.3: Total funding for each project from agencies
SELECT 
    pf.ProjectID,
    p.Title,
    SUM(pf.FundingAmount) AS TotalRevenue
FROM Project_Funding pf
JOIN Projects p ON pf.ProjectID = p.ProjectID
GROUP BY pf.ProjectID, p.Title;

-- Q3.1: Top 5 most popular projects (based on student participation)
SELECT 
    p.ProjectID,
    p.Title,
    COUNT(ps.StudentID) AS TotalStudents
FROM Projects p
LEFT JOIN Project_Student ps ON p.ProjectID = ps.ProjectID
GROUP BY p.ProjectID, p.Title
ORDER BY TotalStudents DESC
LIMIT 5;

-- Q3.3: Average funding of all projects
SELECT AVG(TotalFunding) AS AverageFunding
FROM Projects;

-- Q3.4: Max and min funding
SELECT 
    MAX(TotalFunding) AS MaxFunding,
    MIN(TotalFunding) AS MinFunding
FROM Projects;

-- Q4.1: Top 5 professors based on number of projects
SELECT 
    prof.ProfessorID,
    prof.Name,
    COUNT(p.ProjectID) AS ProjectCount
FROM Professors prof
LEFT JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.ProfessorID, prof.Name
ORDER BY ProjectCount DESC
LIMIT 5;

-- Q5.1: Top 5 departments based on number of students
SELECT 
    Department,
    COUNT(*) AS StudentCount
FROM Students
GROUP BY Department
ORDER BY StudentCount DESC
LIMIT 5;

-- Q5.2: List all designations and number of professors
SELECT 
    Designation,
    COUNT(*) AS ProfessorCount
FROM Professors
GROUP BY Designation;

-- Q6.1: Total funding handled by each professor
SELECT 
    prof.Name,
    SUM(p.TotalFunding) AS TotalFundingManaged
FROM Professors prof
LEFT JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.ProfessorID, prof.Name
ORDER BY TotalFundingManaged DESC;

-- Q6.2: Number of projects managed by each professor
SELECT 
    prof.Name,
    COUNT(p.ProjectID) AS ProjectsManaged
FROM Professors prof
LEFT JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.ProfessorID, prof.Name;

-- Q6.3: Student participating in most projects
SELECT 
    s.Name,
    COUNT(ps.ProjectID) AS TotalProjects
FROM Students s
JOIN Project_Student ps ON s.StudentID = ps.StudentID
GROUP BY s.StudentID, s.Name
ORDER BY TotalProjects DESC
LIMIT 1;

-- ============================================================================
-- PART 6: FILTERING DATA (WHERE Clause)
-- ============================================================================

-- WHERE with comparison operators
SELECT * FROM Projects WHERE TotalFunding > 500000;

-- WHERE with AND, OR
SELECT * FROM Students 
WHERE Department = 'Computer Science' AND City = 'New York';

-- WHERE with BETWEEN
SELECT * FROM Projects 
WHERE TotalFunding BETWEEN 500000 AND 800000;

-- WHERE with LIKE (Pattern Matching)
SELECT * FROM Professors WHERE Name LIKE 'Dr. J%';
SELECT * FROM Students WHERE Email LIKE '%@student.edu';

-- WHERE with IN
SELECT * FROM Students 
WHERE City IN ('New York', 'Boston', 'Chicago');

-- WHERE with IS NULL / IS NOT NULL
SELECT * FROM Projects WHERE EndDate IS NOT NULL;

-- ============================================================================
-- PART 7: AGGREGATE FUNCTIONS
-- ============================================================================

SELECT COUNT(*) AS TotalProjects FROM Projects;
SELECT SUM(TotalFunding) AS TotalFunding FROM Projects;
SELECT AVG(TotalFunding) AS AverageFunding FROM Projects;
SELECT MAX(TotalFunding) AS MaxFunding FROM Projects;
SELECT MIN(TotalFunding) AS MinFunding FROM Projects;

-- GROUP BY with HAVING
SELECT 
    SupervisorID,
    COUNT(*) AS ProjectCount,
    AVG(TotalFunding) AS AvgFunding
FROM Projects
GROUP BY SupervisorID
HAVING COUNT(*) > 2 AND AVG(TotalFunding) > 600000;

-- ============================================================================
-- PART 8: COMBINING DATA (JOINS)
-- ============================================================================

-- INNER JOIN
SELECT 
    p.Title AS ProjectTitle,
    prof.Name AS Supervisor
FROM Projects p
INNER JOIN Professors prof ON p.SupervisorID = prof.ProfessorID;

-- LEFT JOIN
SELECT 
    s.Name AS StudentName,
    ps.ProjectID,
    p.Title AS ProjectTitle
FROM Students s
LEFT JOIN Project_Student ps ON s.StudentID = ps.StudentID
LEFT JOIN Projects p ON ps.ProjectID = p.ProjectID;

-- RIGHT JOIN
SELECT 
    p.Title,
    pub.PublicationID,
    pub.Title AS PublicationTitle
FROM Publications pub
RIGHT JOIN Projects p ON pub.ProjectID = p.ProjectID;

-- FULL OUTER JOIN (MySQL doesn't support directly, use UNION)
SELECT s.Name, ps.ProjectID
FROM Students s
LEFT JOIN Project_Student ps ON s.StudentID = ps.StudentID
UNION
SELECT s.Name, ps.ProjectID
FROM Students s
RIGHT JOIN Project_Student ps ON s.StudentID = ps.StudentID;

-- SELF JOIN (Find professors in same department)
SELECT 
    p1.Name AS Professor1,
    p2.Name AS Professor2,
    p1.Department
FROM Professors p1
JOIN Professors p2 ON p1.Department = p2.Department
WHERE p1.ProfessorID < p2.ProfessorID;

-- ============================================================================
-- PART 9: WINDOW FUNCTIONS (Advanced)
-- ============================================================================

-- ROW_NUMBER: Assign unique row number
SELECT 
    Name,
    Department,
    TotalFunding,
    ROW_NUMBER() OVER (ORDER BY TotalFunding DESC) AS RowNum
FROM Projects p
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID;

-- RANK: Rank with gaps for ties
SELECT 
    Name,
    TotalFunding,
    RANK() OVER (ORDER BY TotalFunding DESC) AS FundingRank
FROM Projects p
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID;

-- DENSE_RANK: Rank without gaps
SELECT 
    Name,
    TotalFunding,
    DENSE_RANK() OVER (ORDER BY TotalFunding DESC) AS DenseRank
FROM Projects p
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID;

-- PARTITION BY: Ranking within groups
SELECT 
    Department,
    Name,
    TotalFunding,
    RANK() OVER (PARTITION BY Department ORDER BY TotalFunding DESC) AS DeptRank
FROM Projects p
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID;

-- LAG and LEAD: Access previous/next row
SELECT 
    Title,
    TotalFunding,
    LAG(TotalFunding) OVER (ORDER BY ProjectID) AS PreviousFunding,
    LEAD(TotalFunding) OVER (ORDER BY ProjectID) AS NextFunding
FROM Projects;

-- Running total using SUM window function
SELECT 
    ProjectID,
    Title,
    TotalFunding,
    SUM(TotalFunding) OVER (ORDER BY ProjectID) AS RunningTotal
FROM Projects;

-- ============================================================================
-- COMPARISON: Aggregate vs Window Functions
-- ============================================================================

-- SCENARIO: Rank projects by funding and show each project's funding vs average

-- METHOD 1: Using Subquery and Aggregate (Less Efficient)
SELECT 
    p.Title,
    p.TotalFunding,
    (SELECT AVG(TotalFunding) FROM Projects) AS AvgFunding,
    p.TotalFunding - (SELECT AVG(TotalFunding) FROM Projects) AS Difference
FROM Projects p
ORDER BY p.TotalFunding DESC;

-- METHOD 2: Using Window Function (More Efficient)
SELECT 
    Title,
    TotalFunding,
    AVG(TotalFunding) OVER () AS AvgFunding,
    TotalFunding - AVG(TotalFunding) OVER () AS Difference,
    RANK() OVER (ORDER BY TotalFunding DESC) AS FundingRank
FROM Projects;

-- Performance comparison query
-- Check execution time using:
SET profiling = 1;
-- Run your query here
SHOW PROFILES;

-- ============================================================================
-- PART 10: INDEXING (Performance Optimization)
-- ============================================================================

-- Create indexes
CREATE INDEX idx_project_funding ON Projects(TotalFunding);
CREATE INDEX idx_student_dept ON Students(Department);
CREATE INDEX idx_professor_name ON Professors(Name);

-- Composite index
CREATE INDEX idx_project_dates ON Projects(StartDate, EndDate);

-- Unique index
CREATE UNIQUE INDEX idx_student_email ON Students(Email);

-- Show indexes
SHOW INDEX FROM Projects;

-- Drop index
-- DROP INDEX idx_project_funding ON Projects;

-- Check query performance with EXPLAIN
EXPLAIN SELECT * FROM Projects WHERE TotalFunding > 600000;

-- ============================================================================
-- PART 11: PARTITIONING (Large Table Optimization)
-- ============================================================================

-- RANGE PARTITIONING by year
CREATE TABLE ProjectsPartitioned (
    ProjectID INT PRIMARY KEY,
    Title VARCHAR(200),
    StartDate DATE,
    TotalFunding DECIMAL(12,2)
)
PARTITION BY RANGE (YEAR(StartDate)) (
    PARTITION p_before_2020 VALUES LESS THAN (2020),
    PARTITION p_2020 VALUES LESS THAN (2021),
    PARTITION p_2021 VALUES LESS THAN (2022),
    PARTITION p_2022_after VALUES LESS THAN MAXVALUE
);

-- LIST PARTITIONING
CREATE TABLE StudentsPartitioned (
    StudentID INT PRIMARY KEY,
    Name VARCHAR(100),
    Department VARCHAR(100)
)
PARTITION BY LIST COLUMNS(Department) (
    PARTITION p_cs VALUES IN ('Computer Science'),
    PARTITION p_ds VALUES IN ('Data Science'),
    PARTITION p_it VALUES IN ('Information Technology'),
    PARTITION p_other VALUES IN ('Artificial Intelligence')
);

-- HASH PARTITIONING
CREATE TABLE PublicationsPartitioned (
    PublicationID INT PRIMARY KEY,
    Title VARCHAR(300),
    PublicationYear YEAR
)
PARTITION BY HASH(PublicationYear)
PARTITIONS 4;

-- Show partition info
SELECT 
    PARTITION_NAME,
    TABLE_ROWS
FROM INFORMATION_SCHEMA.PARTITIONS
WHERE TABLE_NAME = 'ProjectsPartitioned';

-- ============================================================================
-- PART 12: TRIGGERS (Automatic Actions)
-- ============================================================================

-- Trigger to update total funding when new funding is added
DELIMITER $$

CREATE TRIGGER after_funding_insert
AFTER INSERT ON Project_Funding
FOR EACH ROW
BEGIN
    UPDATE Projects
    SET TotalFunding = (
        SELECT SUM(FundingAmount)
        FROM Project_Funding
        WHERE ProjectID = NEW.ProjectID
    )
    WHERE ProjectID = NEW.ProjectID;
END$$

DELIMITER ;

-- Trigger to prevent deletion of active projects
DELIMITER $$

CREATE TRIGGER before_project_delete
BEFORE DELETE ON Projects
FOR EACH ROW
BEGIN
    IF OLD.EndDate > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot delete active projects';
    END IF;
END$$

DELIMITER ;

-- Trigger to log changes
CREATE TABLE ProjectAudit (
    AuditID INT PRIMARY KEY AUTO_INCREMENT,
    ProjectID INT,
    OldFunding DECIMAL(12,2),
    NewFunding DECIMAL(12,2),
    ChangeDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DELIMITER $$

CREATE TRIGGER after_funding_update
AFTER UPDATE ON Projects
FOR EACH ROW
BEGIN
    IF OLD.TotalFunding != NEW.TotalFunding THEN
        INSERT INTO ProjectAudit (ProjectID, OldFunding, NewFunding)
        VALUES (NEW.ProjectID, OLD.TotalFunding, NEW.TotalFunding);
    END IF;
END$$

DELIMITER ;

-- Show triggers
SHOW TRIGGERS;

-- Drop trigger
-- DROP TRIGGER after_funding_insert;

-- ============================================================================
-- PART 13: STORED PROCEDURES
-- ============================================================================

-- Simple stored procedure
DELIMITER $$

CREATE PROCEDURE GetProjectsByFunding(IN minFunding DECIMAL(12,2))
BEGIN
    SELECT * FROM Projects WHERE TotalFunding >= minFunding;
END$$

DELIMITER ;

-- Call procedure
CALL GetProjectsByFunding(600000);

-- Procedure with OUT parameter
DELIMITER $$

CREATE PROCEDURE GetProjectStats(
    OUT totalProjects INT,
    OUT avgFunding DECIMAL(12,2),
    OUT maxFunding DECIMAL(12,2)
)
BEGIN
    SELECT 
        COUNT(*),
        AVG(TotalFunding),
        MAX(TotalFunding)
    INTO totalProjects, avgFunding, maxFunding
    FROM Projects;
END$$

DELIMITER ;

-- Call and display results
CALL GetProjectStats(@total, @avg, @max);
SELECT @total, @avg, @max;

-- ============================================================================
-- PART 14: VIEWS
-- ============================================================================

-- Create a view
CREATE VIEW ActiveProjects AS
SELECT 
    p.ProjectID,
    p.Title,
    prof.Name AS Supervisor,
    p.TotalFunding,
    p.StartDate,
    p.EndDate
FROM Projects p
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID
WHERE p.EndDate > CURDATE();

-- Use view
SELECT * FROM ActiveProjects;

-- Updatable view
CREATE VIEW HighFundingProjects AS
SELECT ProjectID, Title, TotalFunding
FROM Projects
WHERE TotalFunding > 700000;

-- Update through view
UPDATE HighFundingProjects 
SET TotalFunding = 800000 
WHERE ProjectID = 5;

-- Drop view
-- DROP VIEW ActiveProjects;

-- ============================================================================
-- PART 15: SUBQUERIES
-- ============================================================================

-- Subquery in WHERE clause
SELECT Name, Department
FROM Professors
WHERE ProfessorID IN (
    SELECT SupervisorID 
    FROM Projects 
    WHERE TotalFunding > 700000
);

-- Subquery in SELECT clause
SELECT 
    Title,
    TotalFunding,
    (SELECT AVG(TotalFunding) FROM Projects) AS AvgFunding
FROM Projects;

-- Correlated subquery
SELECT p1.Title, p1.TotalFunding
FROM Projects p1
WHERE p1.TotalFunding > (
    SELECT AVG(p2.TotalFunding)
    FROM Projects p2
    WHERE p2.SupervisorID = p1.SupervisorID
);

-- EXISTS
SELECT Name
FROM Professors prof
WHERE EXISTS (
    SELECT 1 
    FROM Projects p 
    WHERE p.SupervisorID = prof.ProfessorID 
    AND p.TotalFunding > 800000
);

-- ============================================================================
-- PART 16: COMMON TABLE EXPRESSIONS (CTEs)
-- ============================================================================

-- Simple CTE
WITH HighFundingProjects AS (
    SELECT * FROM Projects WHERE TotalFunding > 700000
)
SELECT 
    prof.Name,
    COUNT(hfp.ProjectID) AS HighValueProjects
FROM Professors prof
LEFT JOIN HighFundingProjects hfp ON prof.ProfessorID = hfp.SupervisorID
GROUP BY prof.Name;

-- Recursive CTE (Organizational hierarchy example)
WITH RECURSIVE NumberSeries AS (
    SELECT 1 AS n
    UNION ALL
    SELECT n + 1 FROM NumberSeries WHERE n < 10
)
SELECT * FROM NumberSeries;

-- ============================================================================
-- PART 17: SET OPERATIONS
-- ============================================================================

-- UNION (removes duplicates)
SELECT Department FROM Students
UNION
SELECT Department FROM Professors;

-- UNION ALL (keeps duplicates)
SELECT Department FROM Students
UNION ALL
SELECT Department FROM Professors;

-- INTERSECT (MySQL doesn't support directly, use JOIN)
SELECT DISTINCT s.Department
FROM Students s
INNER JOIN Professors p ON s.Department = p.Department;

-- EXCEPT/MINUS (MySQL doesn't support directly, use NOT IN)
SELECT Department FROM Students
WHERE Department NOT IN (SELECT Department FROM Professors);

-- ============================================================================
-- PART 18: CASE STATEMENTS
-- ============================================================================

-- Simple CASE
SELECT 
    Title,
    TotalFunding,
    CASE 
        WHEN TotalFunding >= 800000 THEN 'High Budget'
        WHEN TotalFunding >= 600000 THEN 'Medium Budget'
        ELSE 'Low Budget'
    END AS BudgetCategory
FROM Projects;

-- CASE in aggregate
SELECT 
    Department,
    COUNT(CASE WHEN TotalFunding > 700000 THEN 1 END) AS HighFundingCount,
    COUNT(CASE WHEN TotalFunding <= 700000 THEN 1 END) AS LowFundingCount
FROM Projects p
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID
GROUP BY Department;

-- ============================================================================
-- PART 19: STRING FUNCTIONS
-- ============================================================================

-- CONCAT, SUBSTRING, LENGTH
SELECT 
    CONCAT(Name, ' - ', Department) AS FullInfo,
    SUBSTRING(Name, 1, 10) AS ShortName,
    LENGTH(Name) AS NameLength
FROM Professors;

-- UPPER, LOWER, TRIM
SELECT 
    UPPER(Name) AS UpperName,
    LOWER(Email) AS LowerEmail,
    TRIM('  ' FROM Name) AS TrimmedName
FROM Students;

-- REPLACE, LOCATE
SELECT 
    REPLACE(Email, '@university.edu', '@newdomain.edu') AS NewEmail,
    LOCATE('@', Email) AS AtPosition
FROM Professors;

-- ============================================================================
-- PART 20: DATE AND TIME FUNCTIONS
-- ============================================================================

-- Current date/time
SELECT 
    NOW() AS CurrentDateTime,
    CURDATE() AS CurrentDate,
    CURTIME() AS CurrentTime;

-- Date arithmetic
SELECT 
    Title,
    StartDate,
    EndDate,
    DATEDIFF(EndDate, StartDate) AS DurationDays,
    DATE_ADD(StartDate, INTERVAL 1 YEAR) AS OneYearLater,
    DATE_SUB(EndDate, INTERVAL 6 MONTH) AS SixMonthsBefore
FROM Projects;

-- Date parts
SELECT 
    Title,
    StartDate,
    YEAR(StartDate) AS StartYear,
    MONTH(StartDate) AS StartMonth,
    DAY(StartDate) AS StartDay,
    DAYNAME(StartDate) AS DayOfWeek
FROM Projects;

-- ============================================================================
-- PART 21: NUMERIC FUNCTIONS
-- ============================================================================

SELECT 
    TotalFunding,
    ROUND(TotalFunding, -3) AS RoundedToThousand,
    CEIL(TotalFunding / 1000) AS CeiledThousands,
    FLOOR(TotalFunding / 1000) AS FlooredThousands,
    ABS(TotalFunding - 700000) AS DifferenceFrom700K,
    POWER(TotalFunding / 100000, 2) AS Squared
FROM Projects;

-- ============================================================================
-- PART 22: CONDITIONAL FUNCTIONS
-- ============================================================================

-- IF function
SELECT 
    Title,
    TotalFunding,
    IF(TotalFunding > 700000, 'High', 'Low') AS FundingLevel
FROM Projects;

-- IFNULL / COALESCE
SELECT 
    Name,
    IFNULL(Phone, 'No Phone') AS ContactPhone,
    COALESCE(Phone, Email, 'No Contact') AS PrimaryContact
FROM Professors;

-- NULLIF
SELECT 
    Title,
    NULLIF(TotalFunding, 0) AS NonZeroFunding
FROM Projects;

-- ============================================================================
-- PART 23: RESEARCH PORTAL SPECIFIC QUERIES
-- ============================================================================

-- Q1: Professors supervising multiple projects
SELECT 
    prof.Name,
    COUNT(p.ProjectID) AS ProjectCount
FROM Professors prof
JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.ProfessorID, prof.Name
HAVING COUNT(p.ProjectID) > 1;

-- Q2: Students participating in multiple projects
SELECT 
    s.Name,
    COUNT(ps.ProjectID) AS ProjectCount
FROM Students s
JOIN Project_Student ps ON s.StudentID = ps.StudentID
GROUP BY s.StudentID, s.Name
HAVING COUNT(ps.ProjectID) > 1;

-- Q3: Projects with multiple publications
SELECT 
    p.Title,
    COUNT(pub.PublicationID) AS PublicationCount
FROM Projects p
LEFT JOIN Publications pub ON p.ProjectID = pub.ProjectID
GROUP BY p.ProjectID, p.Title
HAVING COUNT(pub.PublicationID) >= 1;

-- Q4: Projects funded by one or more agencies
SELECT 
    p.Title,
    COUNT(pf.AgencyID) AS FundingAgencyCount,
    SUM(pf.FundingAmount) AS TotalFundingReceived
FROM Projects p
LEFT JOIN Project_Funding pf ON p.ProjectID = pf.ProjectID
GROUP BY p.ProjectID, p.Title
HAVING COUNT(pf.AgencyID) >= 1;

-- Q5: Publications authored by students and/or professors
SELECT 
    pub.Title,
    pub.AuthorType,
    p.Title AS ProjectTitle
FROM Publications pub
JOIN Projects p ON pub.ProjectID = p.ProjectID
WHERE pub.AuthorType IN ('Student', 'Professor', 'Both');

-- Q6: Check constraint - Total funding must not exceed 10,00,000
SELECT 
    Title,
    TotalFunding,
    CASE 
        WHEN TotalFunding > 1000000 THEN 'Exceeds Limit'
        ELSE 'Within Limit'
    END AS FundingStatus
FROM Projects;

-- Q7: Display all students from specific department/city using WHERE
SELECT * 
FROM Students 
WHERE Department = 'Computer Science' OR City = 'New York';

-- Q8: Show all projects with funding greater than 5,00,000
SELECT * 
FROM Projects 
WHERE TotalFunding > 500000;

-- Q9: Display all professors with designation of Associate Professor
SELECT * 
FROM Professors 
WHERE Designation = 'Associate Professor';

-- Q10: Show all funding agencies located in specific country
SELECT * 
FROM FundingAgencies 
WHERE Country = 'USA';

-- ============================================================================
-- PART 24: ADVANCED QUERIES FOR EXAM PREPARATION
-- ============================================================================

-- Find professors who have never supervised any project
SELECT prof.Name
FROM Professors prof
LEFT JOIN Projects p ON prof.ProfessorID = p.SupervisorID
WHERE p.ProjectID IS NULL;

-- Find students not participating in any project
SELECT s.Name
FROM Students s
LEFT JOIN Project_Student ps ON s.StudentID = ps.StudentID
WHERE ps.ProjectID IS NULL;

-- Projects that started in the same year
SELECT 
    p1.Title AS Project1,
    p2.Title AS Project2,
    YEAR(p1.StartDate) AS Year
FROM Projects p1
JOIN Projects p2 ON YEAR(p1.StartDate) = YEAR(p2.StartDate)
WHERE p1.ProjectID < p2.ProjectID;

-- Department-wise funding distribution
SELECT 
    prof.Department,
    COUNT(p.ProjectID) AS TotalProjects,
    SUM(p.TotalFunding) AS TotalFunding,
    AVG(p.TotalFunding) AS AvgFunding
FROM Professors prof
LEFT JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.Department
ORDER BY TotalFunding DESC;

-- Month-wise project start distribution
SELECT 
    YEAR(StartDate) AS Year,
    MONTH(StartDate) AS Month,
    COUNT(*) AS ProjectsStarted
FROM Projects
GROUP BY YEAR(StartDate), MONTH(StartDate)
ORDER BY Year, Month;

-- Complex join: Students, Projects, Professors, Publications
SELECT 
    s.Name AS StudentName,
    p.Title AS ProjectTitle,
    prof.Name AS Supervisor,
    COUNT(pub.PublicationID) AS Publications
FROM Students s
JOIN Project_Student ps ON s.StudentID = ps.StudentID
JOIN Projects p ON ps.ProjectID = p.ProjectID
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID
LEFT JOIN Publications pub ON p.ProjectID = pub.ProjectID
GROUP BY s.StudentID, p.ProjectID, prof.ProfessorID;

-- Funding agency impact analysis
SELECT 
    fa.AgencyName,
    fa.Country,
    COUNT(DISTINCT pf.ProjectID) AS ProjectsFunded,
    SUM(pf.FundingAmount) AS TotalContribution,
    AVG(pf.FundingAmount) AS AvgContribution
FROM FundingAgencies fa
LEFT JOIN Project_Funding pf ON fa.AgencyID = pf.AgencyID
GROUP BY fa.AgencyID, fa.AgencyName, fa.Country
ORDER BY TotalContribution DESC;

-- ============================================================================
-- PART 25: PERFORMANCE ANALYSIS QUERIES
-- ============================================================================

-- Query execution plan
EXPLAIN ANALYZE
SELECT p.Title, prof.Name
FROM Projects p
JOIN Professors prof ON p.SupervisorID = prof.ProfessorID
WHERE p.TotalFunding > 700000;

-- Show query cost
EXPLAIN FORMAT=JSON
SELECT * FROM Projects WHERE TotalFunding > 600000;

-- Database statistics
SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    AVG_ROW_LENGTH,
    DATA_LENGTH,
    INDEX_LENGTH
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'ResearchPortal';

-- ============================================================================
-- PART 26: WINDOW FUNCTION PERFORMANCE COMPARISON
-- ============================================================================

-- SCENARIO: Rank professors by total funding managed and show running total

-- METHOD 1: Using Subqueries (Less Efficient)
SET @start_time1 = NOW(6);

SELECT 
    prof.Name,
    prof.Department,
    (SELECT SUM(TotalFunding) 
     FROM Projects p 
     WHERE p.SupervisorID = prof.ProfessorID) AS TotalFunding,
    (SELECT COUNT(*) 
     FROM Professors p2 
     WHERE (SELECT SUM(TotalFunding) FROM Projects WHERE SupervisorID = p2.ProfessorID) >= 
           (SELECT SUM(TotalFunding) FROM Projects WHERE SupervisorID = prof.ProfessorID)) AS Rank
FROM Professors prof
ORDER BY TotalFunding DESC;

SET @end_time1 = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @start_time1, @end_time1) AS Method1_Microseconds;

-- METHOD 2: Using Window Functions (More Efficient)
SET @start_time2 = NOW(6);

SELECT 
    prof.Name,
    prof.Department,
    SUM(p.TotalFunding) AS TotalFunding,
    RANK() OVER (ORDER BY SUM(p.TotalFunding) DESC) AS FundingRank,
    SUM(SUM(p.TotalFunding)) OVER (ORDER BY SUM(p.TotalFunding) DESC) AS RunningTotal
FROM Professors prof
LEFT JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.ProfessorID, prof.Name, prof.Department
ORDER BY TotalFunding DESC;

SET @end_time2 = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @start_time2, @end_time2) AS Method2_Microseconds;

-- CONCLUSION:
-- Window functions are more efficient because:
-- 1. Single pass through data vs multiple subquery executions
-- 2. Better query optimization by database engine
-- 3. Cleaner, more readable syntax
-- 4. Can perform multiple calculations in one query
-- 5. Reduced I/O operations

-- ============================================================================
-- PART 27: INDEXING PERFORMANCE DEMONSTRATION
-- ============================================================================

-- Query WITHOUT index (measure time)
DROP INDEX IF EXISTS idx_project_funding ON Projects;

SET @start_no_index = NOW(6);
SELECT * FROM Projects WHERE TotalFunding > 600000;
SET @end_no_index = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @start_no_index, @end_no_index) AS NoIndex_Microseconds;

-- Query WITH index (measure time)
CREATE INDEX idx_project_funding ON Projects(TotalFunding);

SET @start_with_index = NOW(6);
SELECT * FROM Projects WHERE TotalFunding > 600000;
SET @end_with_index = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @start_with_index, @end_with_index) AS WithIndex_Microseconds;

-- ============================================================================
-- PART 28: PARTITIONING PERFORMANCE DEMONSTRATION
-- ============================================================================

-- Create partitioned table
CREATE TABLE Projects_By_Year (
    ProjectID INT,
    Title VARCHAR(200),
    StartDate DATE,
    EndDate DATE,
    TotalFunding DECIMAL(12,2),
    SupervisorID INT
)
PARTITION BY RANGE (YEAR(StartDate)) (
    PARTITION p_2019 VALUES LESS THAN (2020),
    PARTITION p_2020 VALUES LESS THAN (2021),
    PARTITION p_2021 VALUES LESS THAN (2022),
    PARTITION p_2022 VALUES LESS THAN MAXVALUE
);

-- Insert data (copy from original table)
INSERT INTO Projects_By_Year SELECT * FROM Projects;

-- Query specific partition (faster)
EXPLAIN PARTITIONS
SELECT * FROM Projects_By_Year 
WHERE StartDate BETWEEN '2021-01-01' AND '2021-12-31';

-- ============================================================================
-- PART 29: USER AUTHENTICATION AND PRIVILEGES
-- ============================================================================

-- Create different user types
CREATE USER 'admin_user'@'localhost' IDENTIFIED BY 'Admin@123';
CREATE USER 'faculty_user'@'localhost' IDENTIFIED BY 'Faculty@123';
CREATE USER 'student_user'@'localhost' IDENTIFIED BY 'Student@123';
CREATE USER 'readonly_user'@'%' IDENTIFIED BY 'ReadOnly@123';

-- Grant privileges to admin (full access)
GRANT ALL PRIVILEGES ON ResearchPortal.* TO 'admin_user'@'localhost';

-- Grant privileges to faculty (read/write on specific tables)
GRANT SELECT, INSERT, UPDATE ON ResearchPortal.Projects TO 'faculty_user'@'localhost';
GRANT SELECT, INSERT ON ResearchPortal.Publications TO 'faculty_user'@'localhost';
GRANT SELECT ON ResearchPortal.Students TO 'faculty_user'@'localhost';

-- Grant privileges to student (read and limited write)
GRANT SELECT ON ResearchPortal.* TO 'student_user'@'localhost';
GRANT INSERT ON ResearchPortal.Project_Student TO 'student_user'@'localhost';

-- Grant read-only access (from any host)
GRANT SELECT ON ResearchPortal.* TO 'readonly_user'@'%';

-- Show grants
SHOW GRANTS FOR 'faculty_user'@'localhost';

-- Revoke specific privileges
REVOKE INSERT ON ResearchPortal.Publications FROM 'faculty_user'@'localhost';

-- Restricted operations example
-- As student_user, try to delete (should fail)
-- DELETE FROM Projects WHERE ProjectID = 1; -- ERROR: Access Denied

-- Drop users
-- DROP USER 'student_user'@'localhost';

-- ============================================================================
-- PART 30: BACKUP AND RESTORE (Command Line)
-- ============================================================================

-- Backup entire database (run in terminal)
-- mysqldump -u root -p ResearchPortal > backup_researchportal.sql

-- Backup specific tables
-- mysqldump -u root -p ResearchPortal Projects Professors > backup_tables.sql

-- Restore database
-- mysql -u root -p ResearchPortal < backup_researchportal.sql

-- ============================================================================
-- PART 31: ERROR HANDLING IN STORED PROCEDURES
-- ============================================================================

DELIMITER $

CREATE PROCEDURE SafeInsertProject(
    IN p_title VARCHAR(200),
    IN p_funding DECIMAL(12,2),
    IN p_supervisor INT,
    OUT p_result VARCHAR(100)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_result = 'Error: Project insertion failed';
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    IF p_funding > 1000000 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Funding exceeds maximum limit';
    END IF;
    
    INSERT INTO Projects (Title, TotalFunding, SupervisorID, StartDate)
    VALUES (p_title, p_funding, p_supervisor, CURDATE());
    
    COMMIT;
    SET p_result = 'Success: Project inserted';
END$

DELIMITER ;

-- Test procedure
CALL SafeInsertProject('New AI Project', 800000, 1, @result);
SELECT @result;

-- ============================================================================
-- PART 32: EXAM-STYLE PRACTICAL QUESTIONS
-- ============================================================================

-- Q1: Find departments with more than 3 professors
SELECT Department, COUNT(*) AS ProfCount
FROM Professors
GROUP BY Department
HAVING COUNT(*) > 3;

-- Q2: List projects that will end within next 6 months
SELECT Title, EndDate
FROM Projects
WHERE EndDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 MONTH);

-- Q3: Find students enrolled in same year as specific student
SELECT s2.*
FROM Students s1
JOIN Students s2 ON YEAR(s1.EnrollmentDate) = YEAR(s2.EnrollmentDate)
WHERE s1.StudentID = 1 AND s2.StudentID != 1;

-- Q4: Calculate percentage contribution of each funding agency
SELECT 
    fa.AgencyName,
    SUM(pf.FundingAmount) AS TotalContribution,
    (SUM(pf.FundingAmount) / (SELECT SUM(FundingAmount) FROM Project_Funding)) * 100 AS Percentage
FROM FundingAgencies fa
JOIN Project_Funding pf ON fa.AgencyID = pf.AgencyID
GROUP BY fa.AgencyID, fa.AgencyName;

-- Q5: Find professors who have supervised projects in multiple years
SELECT 
    prof.Name,
    COUNT(DISTINCT YEAR(p.StartDate)) AS YearsActive
FROM Professors prof
JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.ProfessorID, prof.Name
HAVING COUNT(DISTINCT YEAR(p.StartDate)) > 1;

-- Q6: Second highest funded project
SELECT Title, TotalFunding
FROM Projects
ORDER BY TotalFunding DESC
LIMIT 1 OFFSET 1;

-- Q7: Projects with no student participation
SELECT p.Title
FROM Projects p
LEFT JOIN Project_Student ps ON p.ProjectID = ps.ProjectID
WHERE ps.StudentID IS NULL;

-- Q8: Average funding per department
SELECT 
    prof.Department,
    AVG(p.TotalFunding) AS AvgFunding,
    COUNT(p.ProjectID) AS ProjectCount
FROM Professors prof
JOIN Projects p ON prof.ProfessorID = p.SupervisorID
GROUP BY prof.Department;



/*
COMMON EXAM PATTERNS:

1. AGGREGATE + GROUP BY + HAVING
   - Count/Sum/Avg with grouping and filtering

2. JOINS (Multiple tables)
   - INNER JOIN for matching records
   - LEFT JOIN to include non-matching records
   - Self JOIN for hierarchical data

3. SUBQUERIES
   - IN clause for multiple values
   - EXISTS for checking existence
   - Correlated for row-by-row comparison

4. WINDOW FUNCTIONS
   - ROW_NUMBER for unique ranking
   - RANK for ranking with gaps
   - PARTITION BY for group-wise operations

5. DATE OPERATIONS
   - DATEDIFF, DATE_ADD, DATE_SUB
   - YEAR, MONTH, DAY extraction

6. STRING OPERATIONS
   - CONCAT, SUBSTRING, REPLACE
   - LIKE for pattern matching

7. CASE STATEMENTS
   - Conditional logic in SELECT
   - Creating categories

8. TRANSACTIONS
   - START TRANSACTION
   - COMMIT / ROLLBACK
   - SAVEPOINT

9. INDEXES
   - CREATE INDEX for performance
   - EXPLAIN to check query plan

10. TRIGGERS
    - BEFORE/AFTER INSERT/UPDATE/DELETE
    - Automatic actions
*/

DELIMITER $$

CREATE PROCEDURE SimpleCursorExample()
BEGIN
    -- Step 1: Declare variables to hold data
    DECLARE v_id INT;
    DECLARE v_name VARCHAR(100);
    DECLARE v_amount DECIMAL(10,2);
    DECLARE done INT DEFAULT 0;
    
    -- Step 2: Declare the cursor
    DECLARE my_cursor CURSOR FOR
        SELECT StudentID, Name, Amount
        FROM Students
        WHERE Amount > 1000;
    
    -- Step 3: Declare handler for end of cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
    -- Step 4: Open cursor
    OPEN my_cursor;
    
    -- Step 5: Loop through rows
    read_loop: LOOP
        -- Fetch next row
        FETCH my_cursor INTO v_id, v_name, v_amount;
        
        -- Exit if no more rows
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Step 6: Process each row (your logic here)
        SELECT v_id, v_name, v_amount;
        -- You can also: INSERT, UPDATE, or any other operation
        
    END LOOP;
    
    -- Step 7: Close cursor
    CLOSE my_cursor;
    
END$$

DELIMITER ;

-- Call the procedure
CALL SimpleCursorExample();