#include <stdio.h> 
 
#include <omp.h> 
 
 
 
int main() { 
 
   int i, j; 
 
   int n = 3; // matrix size 
 
 
 
   // Predefined 3x3 matrix 
 
   double A[3][3] = { 
 
       {1.0, 2.0, 3.0}, 
 
       {4.0, 5.0, 6.0}, 
 
       {7.0, 8.0, 9.0} 
 
   }; 
 
 
 
   // Predefined vector 
 
   double x[3] = {1.0, 2.0, 3.0}; 
 
 
 
   // Result vector 
 
   double y[3] = {0.0, 0.0, 0.0}; 
 
 
 
   double start = omp_get_wtime(); 
 
 
 
   printf("Starting parallel matrix-vector multiplication...\n\n"); 
 
 
 
   // Parallel loop 
 
   #pragma omp parallel for private(j) shared(A, x, y, n) 
 
   for (i = 0; i < n; i++) { 
 
       int tid = omp_get_thread_num(); 
 
       printf("  Thread %d is computing Row %d\n", tid,i); 
 
 
 
       for (j = 0; j < n; j++) { 
 
           double product = A[i][j] * x[j]; 
 
           printf("   Thread %d: A[%d][%d] * X[%d] = %.1f * %.1f = %.1f\n", tid, i, j, j, A[i][j], x[j], product); 
 
           y[i] += product; 
 
       } 
 
 
 
       printf(" Thread %d finished Row %d → Y[%d] = %.1f\n\n", tid, i, i, y[i]); 
 
   } 
 
 
 
   double end = omp_get_wtime(); 
 
 
 
   // Print final results 
 
   printf("\nFinal Result Vector (Y = A * X):\n"); 
 
   for (i = 0; i < n; i++) 
 
       printf("Y[%d] = %.1f\n", i, y[i]); 
 
 
 
   printf("\nExecution Time: %f seconds\n", end - start); 
 
 
 
   return 0;
}