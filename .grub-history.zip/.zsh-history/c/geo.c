#include <stdio.h> 
 
#include <stdlib.h> 
 
#include <omp.h> 
 
int main(int argc, char *argv[]) { 
 
   if (argc != 2) { 
 
       printf("Usage: %s N\n", argv[0]); 
 
       return 1; 
 
   } 
 
   int N = atoi(argv[1]); 
 
   double sum = 0.0; 
 
   double last_value = 0.0; 
 
   
 
   #pragma omp parallel 
 
   { 
 
       double local_sum = 0.0; 
 
       int tid = omp_get_thread_num(); 
 
       int thread_worked = 0;  // Flag to track if thread did work 
 
       #pragma omp for schedule(dynamic) ordered 
 
       for (int i = 1; i <= N; i++) { 
 
           double term = 1.0 / (1 << i); 
 
           local_sum += term; 
 
           thread_worked = 1;  // Mark that this thread did work 
 
           #pragma omp ordered 
 
           { 
 
               last_value = term; 
 
           } 
 
       } 
 
       #pragma omp barrier 
 
       #pragma omp critical 
 
       { 
 
           sum += local_sum; 
 
       } 
 
       #pragma omp barrier 
 
       #pragma omp single 
 
       { 
 
           FILE *fp = fopen("series.txt", "w"); 
 
           fprintf(fp, "Sum of series: %f\n", sum); 
 
           fprintf(fp, "Last value in series: %f\n", last_value); 
 
           fclose(fp); 
 
       } 
 
       #pragma omp barrier 
 
       // Only threads that actually worked should write 
 
       if (thread_worked) { 
 
           #pragma omp critical 
 
           { 
 
               FILE *fp = fopen("series.txt", "a"); 
 
               fprintf(fp, "Thread %d contributed\n", tid); 
 
               fclose(fp); 
 
           } 
 
       } 
 
   } 
 
   return 0; 
 
} 
