#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

#define NUM_STUDENTS 10
#define NUM_COMPANIES 4

struct Student {
    char name[50];
    char reg_no[15];
    double pay_package;
    char company[20];
};

int main() {
    struct Student students[NUM_STUDENTS];
    double input_time, count_time, avg_time;
    double start_time, end_time;

    char companies[NUM_COMPANIES][20] = {"Amazon", "Google", "Shell", "Intel"};

    printf("--- Enter Placement Data for %d Students ---\n", NUM_STUDENTS);
    printf("Valid companies are: Amazon, Google, Shell, Intel\n");
    printf("---------------------------------------------\n");
    
    start_time = omp_get_wtime();
    for (int i = 0; i < NUM_STUDENTS; i++) {
        printf("\n=> Enter details for Student %d (Name RegNo Company Pay): ", i + 1);
        scanf("%s %s %s %lf", 
              students[i].name, 
              students[i].reg_no, 
              students[i].company, 
              &students[i].pay_package);
    }
    end_time = omp_get_wtime();
    input_time = end_time - start_time;

    printf("\n--- Data Input Complete. Starting Parallel Analysis ---\n");

    #pragma omp parallel sections
    {
        #pragma omp section
        {
            double start_s2 = omp_get_wtime();
            int tid = omp_get_thread_num();
            
            int company_counts[NUM_COMPANIES] = {0};

            for (int i = 0; i < NUM_STUDENTS; i++) {
                for (int j = 0; j < NUM_COMPANIES; j++) {
                    if (strcmp(students[i].company, companies[j]) == 0) {
                        company_counts[j]++;
                        break;
                    }
                }
            }

            printf("\n----------------------------------------\n");
            printf("Thread %d: Student Count per Company\n", tid);
            printf("----------------------------------------\n");
            for (int i = 0; i < NUM_COMPANIES; i++) {
                printf("%-10s: %d\n", companies[i], company_counts[i]);
            }
            printf("----------------------------------------\n");
            
            double end_s2 = omp_get_wtime();
            count_time = end_s2 - start_s2;
        }

        #pragma omp section
        {
            double start_s3 = omp_get_wtime();
            int tid = omp_get_thread_num();
            
            double total_package = 0.0;
            for (int i = 0; i < NUM_STUDENTS; i++) {
                total_package += students[i].pay_package;
            }

            double average_package = total_package / NUM_STUDENTS;

            printf("\n----------------------------------------\n");
            printf("Thread %d: Average Pay Package\n", tid);
            printf("----------------------------------------\n");
            printf("The average pay package is: %.2f LPA\n", average_package);
            printf("----------------------------------------\n");
            
            double end_s3 = omp_get_wtime();
            avg_time = end_s3 - start_s3;
        }
    }
    printf("R_Sathishkumar 25MCS1009\n");
    printf("\n--- Wall Time Analysis ---\n");
    printf("Task 1 (Data Input) Execution Time : %f seconds\n", input_time);
    printf("Task 2 (Student Count) Execution Time: %f seconds\n", count_time);
    printf("Task 3 (Average Pay) Execution Time: %f seconds\n", avg_time);

    return 0;
}