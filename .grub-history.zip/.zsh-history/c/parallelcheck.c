#include <stdio.h>
#include <omp.h>

int main() {
    int num, sum = 0;

    printf("Enter an integer: ");
    scanf("%d", &num);

    omp_set_num_threads(3);

    #pragma omp parallel sections firstprivate(num) lastprivate(sum)
    {
        #pragma omp section
        {
            printf("\nThread %d checking for Rational Number.\n", omp_get_thread_num());
            printf("Result: %d is a Rational Number.\n", num);
        }

        #pragma omp section
        {
            printf("Thread %d checking for Prime Number.\n", omp_get_thread_num());
            int is_prime = 1;
            if (num <= 1) {
                is_prime = 0;
            } else {
                for (int i = 2; i <= num / 2; ++i) {
                    if (num % i == 0) {
                        is_prime = 0;
                        break;
                    }
                }
            }
            if (is_prime) {
                printf("Result: %d is a Prime Number.\n", num);
            } else {
                printf("Result: %d is not a Prime Number.\n", num);
            }
        }

        #pragma omp section
        {
            printf("Thread %d checking for Perfect Number.\n", omp_get_thread_num());
            sum = 0;
            if (num > 0) {
                for (int i = 1; i <= num / 2; i++) {
                    if (num % i == 0) {
                        sum += i;
                    }
                }
            }
        }
    }

    if (sum == num && num > 0) {
        printf("Result: %d is a Perfect Number.\n\n", num);
    } else {
        printf("Result: %d is not a Perfect Number.\n\n", num);
    }

    return 0;
}
