#include <stdio.h> 
#include <omp.h> 
 
int main() { 
   int n = 0; 
   printf("Enter value of n: "); 
   scanf("%d", &n); 
 
   #pragma omp parallel for ordered 
   for (int i = 1; i <= 2 * n; i++) { 
       #pragma omp ordered 
       { 
           if (i % 2 == 0) { 
               printf("Even: %d\n", i); 
           } else { 
               printf("Odd : %d\n", i); 
           } 
       } 
   } 
 
   return 0; 
} 