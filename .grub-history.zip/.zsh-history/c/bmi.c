    #include <stdio.h>
    #include <omp.h>

    int main(void){
        float h=0,w=0;
        printf("Enter height (in cms) and weight (in kgs)");
        scanf("%f %f",&h, &w);

        #pragma omp parallel
        {
            int tid1 = omp_get_thread_num();
            float h1 = h/100;
            float bmi = w/(h1*h1);
            if(tid1==0){
                int tid2=omp_get_num_threads();
                printf("Total number of threads: %d.\n",tid2);
                printf("This is the master thread TID %d.\n",tid1);
            }else{
                printf("This is thread %d. BMI: %f\n",tid1,bmi);
            }
        }
        return 0;
    }
