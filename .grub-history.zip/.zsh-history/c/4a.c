#include <stdio.h>
#include <omp.h>

#define ORIGINAL_FEE 8000.0
#define TOTAL_BATCHES 8
#define TIER1_STUDENTS 100
#define TIER2_STUDENTS 150
#define TIER3_STUDENTS 150
#define TIER4_STUDENTS 100

int main() {
    double rev_tier1 = 0, rev_tier2 = 0, rev_tier3 = 0, rev_tier4 = 0;
    double total_revenue = 0;
    double start_time, end_time;

    #pragma omp parallel
    {
        #pragma omp master
        {
            printf("Master thread is thread %d\n", omp_get_thread_num());
            printf("Number of processors available: %d\n\n", omp_get_num_procs());
        }
    }

    #pragma omp parallel sections
    {
        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier1 = TIER1_STUDENTS * (ORIGINAL_FEE * 0.40) * TOTAL_BATCHES;
            end_time = omp_get_wtime();
            printf("Tier 1 (60%% discount) calculation wall time: %f seconds\n", end_time - start_time);
        }

        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier2 = TIER2_STUDENTS * (ORIGINAL_FEE * 0.60) * TOTAL_BATCHES;
            end_time = omp_get_wtime();
            printf("Tier 2 (40%% discount) calculation wall time: %f seconds\n", end_time - start_time);
        }

        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier3 = TIER3_STUDENTS * (ORIGINAL_FEE * 0.75) * TOTAL_BATCHES;
            end_time = omp_get_wtime();
            printf("Tier 3 (25%% discount) calculation wall time: %f seconds\n", end_time - start_time);
        }

        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier4 = TIER4_STUDENTS * (ORIGINAL_FEE * 0.90) * TOTAL_BATCHES;
            end_time = omp_get_wtime();
            printf("Tier 4 (10%% discount) calculation wall time: %f seconds\n", end_time - start_time);
        }
    }

    total_revenue = rev_tier1 + rev_tier2 + rev_tier3 + rev_tier4;

    printf("\n--- Monthly Revenue Calculation ---\n");
    printf("Revenue from Tier 1: Rs. %.2f\n", rev_tier1);
    printf("Revenue from Tier 2: Rs. %.2f\n", rev_tier2);
    printf("Revenue from Tier 3: Rs. %.2f\n", rev_tier3);
    printf("Revenue from Tier 4: Rs. %.2f\n", rev_tier4);
    printf("--------------------------------------\n");
    printf("Final Total Revenue Earned in a Month: Rs. %.2f\n", total_revenue);

    return 0;
}