#include <stdio.h>
#include <omp.h>

#define ORIGINAL_COST 10000.0
#define TOTAL_SERVICES 90
#define TIER1_PASSENGERS 20
#define TIER2_PASSENGERS 20
#define TIER3_PASSENGERS 30
#define TIER4_PASSENGERS 30

int main() {
    double rev_tier1 = 0, rev_tier2 = 0, rev_tier3 = 0, rev_tier4 = 0;
    double total_revenue = 0;
    double start_time, end_time;

    #pragma omp parallel
    {
        #pragma omp master
        {
            printf("Master thread is thread %d\n", omp_get_thread_num());
            printf("Number of processors available: %d\n\n", omp_get_num_procs());
            printf("Note: Original ticket cost is assumed to be Rs. %.2f\n\n", ORIGINAL_COST);
        }
    }

    #pragma omp parallel sections
    {
        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier1 = TIER1_PASSENGERS * (ORIGINAL_COST * 0.40) * TOTAL_SERVICES;
            end_time = omp_get_wtime();
            printf("Tier 1 (40%% of cost) calculation wall time: %f seconds\n", end_time - start_time);
        }

        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier2 = TIER2_PASSENGERS * (ORIGINAL_COST * 0.70) * TOTAL_SERVICES;
            end_time = omp_get_wtime();
            printf("Tier 2 (30%% discount) calculation wall time: %f seconds\n", end_time - start_time);
        }

        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier3 = TIER3_PASSENGERS * (ORIGINAL_COST * 0.75) * TOTAL_SERVICES;
            end_time = omp_get_wtime();
            printf("Tier 3 (25%% discount) calculation wall time: %f seconds\n", end_time - start_time);
        }

        #pragma omp section
        {
            start_time = omp_get_wtime();
            rev_tier4 = TIER4_PASSENGERS * (ORIGINAL_COST * 0.90) * TOTAL_SERVICES;
            end_time = omp_get_wtime();
            printf("Tier 4 (10%% discount) calculation wall time: %f seconds\n", end_time - start_time);
        }
    }
    
    total_revenue = rev_tier1 + rev_tier2 + rev_tier3 + rev_tier4;

    printf("\n--- Monthly Revenue Calculation ---\n");
    printf("Revenue from Tier 1: Rs. %.2f\n", rev_tier1);
    printf("Revenue from Tier 2: Rs. %.2f\n", rev_tier2);
    printf("Revenue from Tier 3: Rs. %.2f\n", rev_tier3);
    printf("Revenue from Tier 4: Rs. %.2f\n", rev_tier4);
    printf("--------------------------------------\n");
    printf("Final Total Amount Earned in a Month: Rs. %.2f\n", total_revenue);

    return 0;
}