#include <stdio.h> 
#include <stdlib.h> 
#include <omp.h> 
 
#define MAX 100   
int registered[MAX];  
int count = 0;        
omp_lock_t lock;     
 
 
void register_student(int reg_no) { 
   omp_set_lock(&lock); 
   if (count < MAX) { 
       registered[count++] = reg_no; 
       printf("Student %d registered successfully.\n", reg_no); 
   } else { 
       printf("Registration full, student %d cannot register.\n", reg_no); 
   } 
   omp_unset_lock(&lock); 
} 
 
 
void unregister_student(int reg_no) { 
   omp_set_lock(&lock); 
   int found = -1; 
   for (int i = 0; i < count; i++) { 
       if (registered[i] == reg_no) { 
           found = i; 
           break; 
       } 
   } 
   if (found != -1) { 
       for (int i = found; i < count - 1; i++) { 
           registered[i] = registered[i + 1]; 
       } 
       count--; 
       printf("Student %d unregistered successfully.\n", reg_no); 
   } else { 
       printf("Student %d not found in registered list.\n", reg_no); 
   } 
   omp_unset_lock(&lock); 
} 
 
 
void view_registered() { 
   printf("\nCurrent Registered Students:\n"); 
   #pragma omp parallel for ordered 
   for (int i = 0; i < count; i++) { 
       #pragma omp ordered 
       printf("%d ", registered[i]); 
   } 
   printf("\n\n"); 
} 
 
int main() { 
   omp_init_lock(&lock); 
 
   
   #pragma omp parallel sections 
   { 
       #pragma omp section 
       { 
           register_student(9); 
       } 
       #pragma omp section 
       { 
           register_student(3); 
       } 
       #pragma omp section 
        { 
            register_student(2); 
        } 
        #pragma omp section 
        { 
            unregister_student(3); 
        } 
} 
    view_registered(); 
    omp_destroy_lock(&lock); 
    return 0; 
}